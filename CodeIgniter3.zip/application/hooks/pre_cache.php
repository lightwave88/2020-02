<?php
namespace ci\app\hooks;

function interceptor_1() {

    printf('<p>hook interceptor_1 start</p>');

    // console()->dump(func_get_args());

    printf('<p>hook interceptor_1 end</p>');
}
