<?php

namespace ci\app\hooks;

use ci\system\hook\CI_Hook;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Test1 extends CI_Hook {

    public function pre_controller($context) {
                
        print('<p>---hook Test1->pre_system()---</p>');
        // console()->dump(\get_container());

        print('<p>---hook Test1->pre_system()---</p>');
    }

}
