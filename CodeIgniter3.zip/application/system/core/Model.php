<?php

namespace ci\system;

use ci\system\fun;

defined('BASEPATH') OR exit('No direct script access allowed');

class CI_Model extends CI_ContainerABS {

    public function __construct() {
        parent::__construct();

        fun\container_load_cores($this);

        $file = BASEPATH . 'core1/Loader/Loader_basic.php';
        $class = SYS_ROOT_NAMESPACE . 'CI_Loader_basic';
        $this->load = &fun\load_class($class, $file, array($this));
    }

    //--------------------------------------------------------------------------
}
