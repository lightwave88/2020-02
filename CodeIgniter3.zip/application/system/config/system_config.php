<?php

/**
 * container 要注入的 core
 */
$config['test'] = 'test';
