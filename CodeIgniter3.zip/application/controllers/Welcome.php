<?php

namespace ci\app\controllers;

use ___PHPSTORM_HELPERS\object;
use ci\system\CI_Controller;

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    
    public function index() {

        // $CI = get_instance();
        // console()->dump($this);

        // $this->load->lib('calendar');
        printf('<p>Wellcome index</p>');
       
        
        $this->load->database();

        $query = $this->db->query('SELECT * FROM book_class');
        console()->dump($query->result_array());

        $query = $this->db->get('book_class');
        console()->dump($query->result_array());
        
        $view = $this->load->view();

        $view->load('welcome_message');
        
        // $view = '<h1>hi</h1>';

        return $view;

    }

}
