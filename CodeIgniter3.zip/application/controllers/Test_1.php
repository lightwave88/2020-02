<?php

namespace ci\app\controllers;

use ci\system\CI_Controller;

class Test_1 extends CI_Controller {
    
    public function index(){
        print('<h1>test_1->index()</h1>');
        $this->load->model('room');

        $this->load->lib('xyz');
        
        console()->dump(get_object_vars($this));

        $this->m_room->showList();
    }
    //--------------------------------------------------------------------------
    public function t1() {
        \Lib::load_class('g', function() {
            $file = BASEPATH . 'libraries/Xyz.php';
            if (!class_exists('\\libraries\\CI_Xyz')) {
                require_once($file);
            }
            return '\\libraries\\CI_Xyz';
        });
        
        $g = \Lib::load('g');
        Console()->dump($g);
        
        print('<hr>');
        \Console::dump(lib()->test());
    }
    
    //--------------------------------------------------------------------------
    public function t2() {
        
        console()->log('controller >> Test_1->index()');
        $xyz = lib()->load('xyz');
        $xyz = lib()->load('xyz');
        console()->dump($xyz);


        console()->dump(lib());
        console()->dump(\Lib::test());
    }

}
