<?php
namespace ci\app\models;
use ci\system\CI_Model;

class Room extends CI_Model {

    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function showList() {
        $query = $this->db->query('select * from `room`');
        $res = $query->result_array();
        
        console()->dump($res);
    }

}
