<?php

header('Content-Type:text/html;charset=utf-8');
$path = './application/config/interceptors/interceptors.xml';

/*
  返回檔案上次被修改的時間，出錯時返回 FALSE。時間以 Unix 時間戳的方式返回，可用於 date()。
  例如：
 */
$a = filemtime($path);
printf('<p>案上次被修改的時間：(%s)</p>', date("Y-m-d H:i:s", $a));

/*
  返回檔案上次 inode 被修改的時間，如果出錯則返回 FALSE。時間以 Unix 時間戳的方式返回。
  例如：
 */
$a = filectime($path);
printf('<p>檔案上次 inode 被修改的時間：(%s)</p>', date("Y-m-d H:i:s", $a));

/*
  返回檔案上次被訪問的時間，如果出錯則返回 FALSE。時間以 Unix 時間戳的方式返回。
  例如：
 */
$a = fileatime($path);
printf('檔案上次被訪問的時間：(%s)', date("Y-m-d H:i:s", $a));

