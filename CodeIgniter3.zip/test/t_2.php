<?php

namespace a {

    function test() {

        $c = 'G';
        $command = <<<COM
                namespace b;
    class {$c}{
    }
COM;

        try {
            $b = eval($command);
        } catch (Exception $exc) {
            echo $exc->getMessage();
        }

        printf('<p>%s, %s</p>', @$a, @$b);
    }

}

namespace {
    \a\test();
//    \a\test();

    print('<pre>');
    var_export(get_declared_classes());
    print('</pre>');
}