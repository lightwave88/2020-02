<?php

$data = array(5, 4, 1);

while (($d = array_shift($data)) && test($d)) {
    printf('<p>%s</p>', $d);
}

function test($v) {
    return isset($v);
}
