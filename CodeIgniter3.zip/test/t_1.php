<?php

$d = array(
    '-1',
    '0',
    0,
    '',
    '   ',
    '1'
);


foreach ($d as $value) {
    printf('<p>(%s)=>(%s)</p>', $value, empty($value));
}
