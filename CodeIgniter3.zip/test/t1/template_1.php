<?php ?>
<p>1.....</p>

<?php
$this->section('a');
?>

<h1>section a start</h1>
<?php
$this->section('c');
?>
<h1>section c start</h1>

<?php
$this->section('b');
?>

<h1>section b</h1>

<?php
$this->endSection('b');
?>

<h1>section c end</h1>
<?php
$this->endSection('c');
?>


<h1>section a end</h1>

<?php
$this->endSection('a');
?>

<p>2.....</p>

<?php
