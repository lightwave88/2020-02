<?php

print('<p>a</p>');

ob_start();

printf('<p>b(%s)</p>', ob_get_level());

//-----------------------

ob_start();

printf('<p>c(%s)</p>', ob_get_level());

$a = ob_get_flush();
//-----------------------

printf('<p>d(%s)</p>', ob_get_level());

$b = ob_get_flush();

printf('<p>e(%s)</p>', ob_get_level());

printf('<hr>');
printf('<p>a(%s)', $a);
printf('<p>b(%s)', $b);
