<?php

namespace ci\system;

/**
 * javascript console
 */
class CI_Console {

    protected static $_ci_core;
    protected static $instance;

    //--------------------------------------------------------------------------
    public static function &get_instance() {

        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    //--------------------------------------------------------------------------
    protected function __construct() {
        self::$instance = &$this;

        if (!class_exists('\Console')) {
            $file = BASEPATH . 'core1/global_var/VAR_console.php';
            \include_class($file, '\Console', TRUE);
            \Console::get_instance($this);
        }
    }

    //--------------------------------------------------------------------------
    public function log() {
        $args = func_get_args();
        $res = '';

        if (count($args) > 0) {
            // var_dump($args);
            $res = call_user_func_array('\printf', $args);
        }
        printf('<pre>%s</pre>', $res);
    }

    //--------------------------------------------------------------------------
    public function dir($data) {
        print('<pre>');
        echo json_encode($data);
        print('</pre>');
    }

    //--------------------------------------------------------------------------
    public function var_dump($data) {
        print('<pre>');
        var_dump($data);
        print('</pre>');
    }

    public function dump($data){
        $this->var_dump($data);
    }
    //--------------------------------------------------------------------------


    public function var_export($data) {
        print('<pre>');
        var_export($data);
        print('</pre>');
    }

    public function export($data){
        $this->export($data);
    }

    //--------------------------------------------------------------------------
    public function print_r($data) {
        print('<pre>');
        print_r($data);
        print('</pre>');
    }

    //--------------------------------------------------------------------------
    function test1() {
        $CFG = &load_class('Config', 'core');
        $URI = load_class('URI', 'core');

        $cache_path = ($CFG->item('cache_path') === '') ? APPPATH . 'cache/' : $CFG->item('cache_path');

        $a = $CFG->item('base_url');
        $b = $CFG->item('index_page');

        // direct|c|m|query
        $c = $URI->uri_string;

        printf('<p>%s | %s | %s</p>', $a, $b, $c);

        // Build the file path. The file name is an MD5 hash of the full URI
        $uri = $a . $b . $c;

        printf('<p>$_SERVER[\'QUERY_STRING\']=%s', json_encode($_SERVER['QUERY_STRING']));

        $cache_query_string = $CFG->item('cache_query_string');
        $cache_query_string = array('c', 'b');

        if ($cache_query_string && !empty($_SERVER['QUERY_STRING'])) {

            // key 與 value 互換
            $a = array_flip($cache_query_string);

            // 取兩 array 交集
            $b = array_intersect_key($_GET, $a);

            // 取得 query_string
            $c = http_build_query($b);

            printf('<p>query_string=%s</p>', $c);

            if (is_array($cache_query_string)) {
                $uri .= '?' . $c;
            } else {
                // 通常進入此
                $uri .= '?' . $_SERVER['QUERY_STRING'];
            }
        }

        $filepath = $cache_path . md5($uri);

        printf('<pre>');

        $ci = get_instance();

        var_export(get_object_vars($ci));
        printf('</pre>');
    }

}
