<?php

/**
 * container 要注入的 core
 */
$config['core_loadList'] = array(
    'Benchmark',
    'Config',
    'Input',
    'Lang',
    'Log',
    'Router',
    'Utf8',
    'URI',
    'Security'
);

//------------------------------------------------------------------------------

/*
 * 放置 core 的目錄
 */
$config['core']['module_dir'] = array(
    (APPPATH . 'system/core/'),
    (BASEPATH . 'core/')
);

$config['core']['root_namespace'] = '\\ci\\system\\';

//------------------------------------------------------------------------------
/**
 * library 要轉換的名稱
 */
$config['library']['varmap'] = array(
    'unit_test' => 'unit',
    'user_agent' => 'agent'
);
//-----------------------------------------------------------------------------
/**
 * actionResult 會放的路徑
 */
$config['action_result']['result_file_dir'] = array(
    (APPPATH . 'system/action_results/'),
    (BASEPATH . 'core1/action_results/')
);

/**
 * resultClass 的 namespace
 */
$config['action_result']['result_class_namespace'] = SYS_ROOT_NAMESPACE . 'result\\';

//-----------------------------------------------------------------------------
$config['hook']['hook_class_dir'] = APPPATH . 'hooks/';

/**
 * hook_scope 會放的路徑
 */
$config['hook']['context_class_dir'] = array(
    (APPPATH . 'system/hook_contexts/'),
    (BASEPATH . 'core1/Hook/hook_contexts/')
);

$config['hook']['container_namespace'] = APP_ROOT_NAMESPACE . 'hooks\\';

$config['hook']['context_namespace'] = SYS_ROOT_NAMESPACE . 'hook\\';


// hook.pre_controller 可用的 result 
$config['hook']['pre_controller']['result_list'] = array(
    'redirect_result',
    'error_result'
);
//-----------------------------------------------------------------------------
/*
 * 預設視圖引擎
 * 可能改放 user_config
 */
$config['view_engine']['default_engine'] = 'ci3';

/*
 * 視圖引擎放置的目錄
 */
$config['view_engine']['module_dir'] = array(
    (APPPATH . 'view_engine/'),
    (BASEPATH . 'view_engine/')
);

//-----------------------------------------------------------------------------
/*
 * database 引擎的根 namespace
 */
$config['database']['root_namespace'] = '\\ci\\system\\database\\';

$config['database']['default_engine'] = 'ci3';

/*
 * ci3 expandAPI 會放置的目錄
 */
$config['database']['ci3_expandAPI_dir'] = array(
    (APPPATH.'system/database/ci3/expand_api/'),
    (BASEPATH.'database/ci3/expand_api/')
);

/*
 * 放置 database.config 的根目錄
 */
$config['database']['config_dir'] = array(
    (APPPATH . 'config/' . ENVIRONMENT . '/database/'),
    (APPPATH . 'config/database/')
);
//-----------------------------------------------------------------------------
$config['controller']['default_method'] = 'index';

//-----------------------------------------------------------------------------
$config['model']['class_dir'] = APPPATH.'models/';
//-----------------------------------------------------------------------------
