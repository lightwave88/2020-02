<?php

use ci\database\ci3\CI_DB_driver;

class CI_DB extends CI_DB_driver {

    public $db_core;

    public function __call($name, $arguments) {
        return call_user_func_array(array($this->db_core, $name), $arguments);
    }

}
