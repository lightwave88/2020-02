<?php
/**
 * 全域
 */
class DB {
    
}
