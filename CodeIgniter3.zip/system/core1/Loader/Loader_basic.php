<?php

namespace ci\system;

use ci\system\fun;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_Loader_ABS')) {
    require_once(__DIR__ . '/Loader_ABS.php');
}

/**
 * GlobaContext 專用
 *
 */
class CI_Loader_basic extends CI_Loader_ABS {

    public function __construct(CI_ContainerABS $container) {
        parent::__construct($container);
    }

    //--------------------------------------------------------------------------

    public function library($moduleName, $params = NULL, $name = NULL, $single = TRUE) {

        if (empty($name)) {
            $name = $moduleName;
        }
        $varName = fun\key_getModuleVarName($name);
        //------------------
        $target = $this->_ci_container;

        $lib = &\lib($moduleName, $params, $single);

        if (isset($target->$varName)) {
            if ($target->$varName !== $lib) {
                throw new \Exception('.............');
            }
            return $this;
        }
        //------------------
        $target->$varName = $lib;

        // is_loaded
        $_ci_classes = &$this->_ci_container->_ci_classes;

        // 登記 varName
        $list = fun\key_checkModuleName($moduleName);
        $moduleName = $list[1];

        $_moduleName = empty($list[0]) ? $list[1] : sprintf('%s\\%s', $list[0], $list[1]);
        $_moduleName = strtolower($_moduleName);

        if (strcmp($varName, $_moduleName) != 0) {
            $_ci_classes[$varName] = $_moduleName;
        }

        // 登記 className
        $class = get_class($lib);
        $class = fun\key_checkClassName($class, TRUE);
        $class = $class;

        $_ci_classes[$_moduleName] = $class;

        return $this;
    }

    //--------------------------------------------------------------------------
    public function lib($moduleName, $params = NULL, $object_name = NULL, $single = TRUE) {
        return $this->library($moduleName, $params, $object_name, $single);
    }

    //--------------------------------------------------------------------------
    public function app($object_name, $class, $params = NULL, $name = NULL, $single = TRUE) {
        
    }

    //--------------------------------------------------------------------------
    public function config($file, $use_sections = FALSE, $fail_gracefully = FALSE) {
        
    }

    //--------------------------------------------------------------------------
    public function driver($library, $params = NULL, $object_name = NULL) {
        
    }

    //--------------------------------------------------------------------------
    public function file($path, $return = FALSE) {
        // 重點
    }

    //--------------------------------------------------------------------------
    public function helper($helpers = array()) {
        
    }

    //--------------------------------------------------------------------------
    public function helpers($helpers = array()) {
        
    }

    //--------------------------------------------------------------------------

    /**
     * old API
     * 取得模組對應的 var
     *
     * @param type $class
     * @return type
     */
    final public function is_loaded($moduleName) {
        $_ci_classes = $this->_ci_container->_ci_classes;

        if (preg_match('/.+::class$/', $moduleName)) {
            $class = fun\key_checkClassName($moduleName);

            $key = array_search($class, $_ci_classes, TRUE);

            if ($key !== false) {
                $_key = array_search($class, $_ci_classes, TRUE);
                if ($_key !== false) {
                    $key = $_key;
                }
                return $key;
            }
        } else {
            $list = fun\key_checkModuleName($moduleName);
            $moduleName = empty($list[0]) ? $list[1] : sprintf('%s\\%s', $list[0], $list[1]);
            $moduleName = strtolower($moduleName);

            $key = array_search($moduleName, $_ci_classes, TRUE);

            if ($key !== false) {
                return $key;
            }
        }
        return FALSE;
    }

    //--------------------------------------------------------------------------
    public function language($files, $lang = '') {
        
    }

    //--------------------------------------------------------------------------
    public function model($modelName, $name = '', $single = true) {

        $single = !!$single;
        $container = $this->_ci_container;
        $_ci_models = &$container->_ci_models;

        $list = fun\key_checkModuleName($modelName);
        $subdir = $list[0];
        $_modelName = $list[1];

        $modelName = empty($list[0]) ? $list[1] : sprintf('%s\\%s', $subdir, $_modelName);
        $m_name = strtolower($modelName);

        $var_name = !empty($name) ? $name : fun\key_getModuleVarName($modelName);
        $var_name = 'm_' . $var_name;

        $model = &\model($modelName, $single);

        if (isset($container->$var_name)):
            if ($container->$var_name !== $_ci_models[$m_name]) {
                throw new \Exception("..............");
            }
            return $this;
        endif;
        //------------------

        $container->$var_name = $model;

        $_ci_models[$var_name] = $m_name;

        $class = get_class($model);
        $class = fun\key_checkClassName($class, true);
        $_ci_models[$m_name] = $class;

        return $this;
    }

    //--------------------------------------------------------------------------

    /**
     * old API，有其他模組會用到
     *
     * Return a list of all package paths.
     *
     * @param	bool	$include_base	Whether to include BASEPATH (default: FALSE)
     * @return	array
     */
    public function get_package_paths($include_base = FALSE) {
        $library_paths = array(APPPATH, BASEPATH);
        $model_paths = array(APPPATH);
        return ($include_base === TRUE) ? $library_paths : $model_paths;
    }

    //--------------------------------------------------------------------------

    /**
     * 啟動資料庫模組
     * 
     * @param type $moduleName
     * @param type $params
     * @param type $return
     * @return type
     * @throws \Exception
     */
    public function database($moduleName = '', $params = '', $nick_name = '', $single = true) {
        $single = !!$single;

        $moduleName = '' . $moduleName;

        if (empty($nick_name)) {
            $nick_name = $moduleName;
        }
        //------------------
        $db_list = &$this->_ci_container->_ci_databaseList;

        $default_database = fun\coreConfig('database.default_engine');

        $judge = strcasecmp($moduleName, $default_database);
        if (empty($moduleName) || $judge == 0) {
            $moduleName = 'ci3';
            $var_name = '';
        } else {
            $var_name = strtolower($moduleName);
        }

        $var_name = empty($var_name) ? 'db' : ('db_' . $var_name);

        $container = &$this->_ci_container;

        // 實例化資料庫模組
        $db = &\load_database($moduleName, $params, $single);

        if (isset($container->$var_name)):
            if ($container->$var_name !== $db) {
                throw new \Exception(".......................");
            }
            return $this;
        endif;
        //------------------
        $db_list[$var_name] = $moduleName;
        $container->$var_name = $db;

        return $this;
    }

    //--------------------------------------------------------------------------

    /**
     * CI Component getter
     *
     * Get a reference to a specific library or model.
     *
     * @param 	string	$component	Component name
     * @return	bool
     */
    protected function &_ci_get_component($component) {
        $CI = &$this->_ci_container;
        return $CI->$component;
    }

}
