<?php

namespace ci\system\result;

class CI_File_result {

    protected $_ci_file;
    protected $_ci_content_type;
    protected $_ci_download_name;
    protected $_ci_content;

    public function __construct($file, $contentType, $downloadName = '') {
        $this->_ci_file = '' . $file;
        $this->_ci_content_type = $contentType;

        if (!empty($downloadName)) {
            $this->_ci_download_name = $downloadName;
        }
    }

    //--------------------------------------------------------------------------
    public function setContentType($type) {
        $this->_ci_content_type = $type;
    }

    //--------------------------------------------------------------------------
    public function setDownloadName($name) {
        $this->_ci_download_name = $name;
    }

    //--------------------------------------------------------------------------
    public function ExecuteResult() {
        $this->_ci_content = $this->_getContent();
    }

    //--------------------------------------------------------------------------
    public function getOutput() {
        return $this->_ci_content;
    }

    //--------------------------------------------------------------------------

    /**
     * 取得檔案內容
     */
    protected function _getContent() {
        
    }

}
