<?php

namespace ci\system\result;

class CI_Redirect_result implements CI_ActionResult_redirect {

    public $_ci_url;
    public $_ci_method;
    public $_ci_controller;

    //--------------------------------------------------------------------------
    public function __construct() {
        
    }

    public function ExecuteResult() {
        
    }

    //--------------------------------------------------------------------------
    public function getRedirect() {
        
    }

}
