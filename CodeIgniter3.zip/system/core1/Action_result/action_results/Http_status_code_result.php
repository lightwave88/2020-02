<?php

namespace ci\system\result;

class CI_Http_status_code_result implements CI_ActionResult {
    
    protected $_ci_status;
    
    protected $_ci_message = '';
    //--------------------------------------------------------------------------
    public function __construct($statuscode, $message = '') {
        $this->_ci_status = $statuscode;
        
        if(!empty($message)){
            $this->_ci_message = ''.$message;
        }
    }
    //--------------------------------------------------------------------------
    public function ExecuteResult() {
        
    }

}
