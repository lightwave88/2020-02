<?php

namespace ci\system\result;

class CI_Layot_result implements CI_ActionResult_output {

    protected $_ci_content = '';

    public function __construct() {
        
    }

    //--------------------------------------------------------------------------
    public function ExecuteResult() {
        
    }

    //--------------------------------------------------------------------------
    public function getOutput() {
        return $this->_ci_content;
    }

}
