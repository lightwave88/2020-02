<?php

namespace ci\system;

use ci\system\fun;

defined('BASEPATH') OR exit('No direct script access allowed');

abstract class CI_ContainerABS {

    /**
     * List of loaded classes
     *
     * @var	array
     */
    public $_ci_classes = array();

    /**
     * 上下文
     * 只對 model, filter, hook 有用
     * 
     * @var type 
     */
    public $_ci_context;

    /**
     * 被 load 的資料庫模組
     * 
     * @var type 
     */
    public $_ci_databaseList = array();
    //-----------------------

    /**
     * load 模組
     *
     * @var object
     */
    public $load;

    /**
     * 放置 model
     *
     * @var array
     */
    public $_ci_models = array();

    //--------------------------------------------------------------------------
    public function __construct() {
        
    }

}

//==============================================================================
/**
 * Hook, Filter
 */
abstract class CI_Item1_container extends CI_ContainerABS {

    public function __construct() {
        parent::__construct();
    }

}
