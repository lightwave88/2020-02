<?php

namespace ci\system;

use ci\system\fun;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_ContainerABS')) {
    require_once(__DIR__ . '/ContainerABS.php');
}

/**
 * Description of CI_Controller
 *
 * @author xman
 */
abstract class CI_Controller extends CI_ContainerABS {
    
    public $_ci_level = 0;
    /**
     * controller 套嵌
     * 
     * @var type 
     */
    public $_ci_parent;

    /**
     * view engine 要使用的
     * 
     * @var type 
     */
    public $_ci_ob_level;

    /*
     * 是否已完成 construct
     */
    public $_ci_inited = false;

    //--------------------------------------------------------------------------
    //put your code here
    public function __construct(\ci\system\CI_Controller $parent = NULL) {

        parent::__construct();

        if (!empty($parent)) {
            $this->_ci_parent = $parent;
            $this->_ci_level = $this->_ci_parent->_ci_level + 1;
        }

        fun\container_load_cores($this);

        $file = BASEPATH . 'core1/Loader/Controller_loader.php';

        $class = SYS_ROOT_NAMESPACE . 'CI_Controller_loader';
        $this->load = &fun\load_class($class, $file, array($this));
    }

    //--------------------------------------------------------------------------

    /**
     * 呼叫 conroller 取得網頁內容
     *
     * @param type $controller
     * @param type $method
     * @param array $args
     */
    protected static function callController($controller, $controllerName, $method = NULL, array $args = array()) {

        $options = array();

        $data = &fun\callController($controller, $options);
    }

}
