<?php

namespace ci\system\hook;

abstract class CI_Hook_context {

    abstract public function getResult($resultName);

    /**
     * 回傳 false 會終止整個程序 
     */
    abstract public function _ci_checkResult($result);
}
