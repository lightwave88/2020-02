<?php

namespace ci\system\hook;

use ci\system\fun;

class CI_Pre_controller extends CI_Hook_context {
    //--------------------------------------------------------------------------

    /**
     * 當接獲使用者的 result 要如何處理
     */
    public function _ci_checkResult($result) {
        return NULL;
    }

    //--------------------------------------------------------------------------

    /**
     * 使用者可取得他要的 result
     */
    public function getResult($resultName) {

        $index = strtolower($resultName);

        // 取得可以使用的 result 列表
        $allowList = fun\coreConfig('hook.pre_controller.result_list');

        if (!in_array($index, $allowList)) {
            throw new \Exception("request result($resultName) can\'t allow in this scope");
        }

        $class = fun\get_actionResult($resultName);

        return NULL;
    }

}
