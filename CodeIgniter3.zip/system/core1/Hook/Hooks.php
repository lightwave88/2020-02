<?php

namespace ci\system\hook;

use ci\system\fun;

defined('BASEPATH') OR exit('No direct script access allowed');

class CI_Hooks {

    /**
     * Determines whether hooks are enabled
     *
     * @var	bool
     */
    public $enabled = FALSE;

    /**
     * List of all hooks set in config/hooks.php
     *
     * @var	array
     */
    public $hooks = array();

    /**
     *
     * @var type 
     */
    public $contexts = array();

    /**
     * Array with class objects to use hooks methods
     * 單例的記錄
     *
     * @var array
     */
    protected $_hook_instance = array();

    /**
     * In progress flag
     *
     * Determines whether hook is in progress, used to prevent infinte loops
     *
     * @var	bool
     */
    protected $_in_progress = FALSE;

    // -------------------------------------------------------------------------

    /**
     * Class constructor
     *
     * @return	void
     */
    public function __construct() {

        log_message('info', 'Hooks Class Initialized');

        // If hooks are not enabled in the config file
        // there is nothing else to do
        if (config('enable_hooks') === FALSE) {
            return;
        }

        // Grab the "hooks" definition file.
        if (file_exists(APPPATH . 'config/hooks.php')) {
            include(APPPATH . 'config/hooks.php');
        }

        if (file_exists(APPPATH . 'config/' . ENVIRONMENT . '/hooks.php')) {
            include(APPPATH . 'config/' . ENVIRONMENT . '/hooks.php');
        }
        //------------------
        // If there are no hooks, we're done.
        if (!isset($hook) || !is_array($hook)) {
            return;
        }
        //------------------
        
        $this->hooks = & $hook;
        $this->enabled = TRUE;
    }

    // -------------------------------------------------------------------------

    /**
     * Call Hook
     * 執行單一 hookSetting
     *
     * Calls a particular hook. Called by CodeIgniter.php.
     *
     * @uses	CI_Hooks::_run_hook()
     *
     * @param	string	$which	Hook name
     * @return	bool	TRUE on success or FALSE on failure
     */
    public function call_hook($which = '') {

        console()->log('call_hook(%s)', $which);
        
        // 確認載入所需的 class
        $this->_checkClass();

        $which = strtolower($which);

        if (!$this->enabled || !isset($this->hooks[$which])) {
            // 返回已有的單例
            return FALSE;
        }
        //------------------
        /*
         * 取得該階段的 scope
         * scope 決定該階段可用啥功能
         */
        $context = &$this->_get_context($which);

        $runList = array();

        /*
         * 取得使用者對 hook 的設定
         */
        if (is_array($this->hooks[$which]) && is_array($this->hooks[$which][0])) {
            $runList = $this->hooks[$which];
        } else {
            // 設定檔是單一
            $runList[] = $this->hooks[$which];
        }
        //------------------
        // $returnVal = TRUE;
        // 執行所有 hookSetting
        // 設定檔是 array
        foreach ($runList as $k => $val) {

            try {
                // 跑每個設定檔
                $return = $this->_run_hook($val, $which, $context);
            } catch (\Exception $exc) {

                /*
                 * 發生錯誤，或拋出錯誤
                 * 將停止所有步驟
                 */
                $this->_in_progress = FALSE;

                $error = sprintf('hook state(%s): %s', $which, $exc->getMessage());
                exit($error);
            }
            //------------------           

            if ($return === FALSE) {
                // hookSetting 回傳 FALSE 則停止後續的 hookSetting
                // 繼續往下面執行
                // $returnVal = FALSE;
                console()->log(sprintf('hook stop (%s)', json_encode($val)));
                break;
            } else if (is_a($return, (SYS_ROOT_NAMESPACE . 'result\\CI_ActionResult'))) {
                // 有可能是資訊輸出
                // cotroller, method 重導
                // 停止後續的 hookSetting
                // 繼續往下面執行
                // $returnVal = FALSE;
                // 使用者回傳他想中斷的命令
                $result = $return->ExecuteResult();

                // 由 scope 決定如何執行命令
                if ($context->_ci_checkResult($result) === false) {
                    exit();
                }
                break;
            }
        }
    }

    // -------------------------------------------------------------------------

    /**
     * Run Hook
     *
     * Runs a particular hook
     *
     * @param	array	$data	Hook details
     * @return	bool	TRUE on success or FALSE on failure
     */
    protected function _run_hook($data, $which, $context) {

        console()->log('<p>run hook(%s)</p>', json_encode($data));
        // Safety - Prevents run-away loops
        // -----------------------------------
        // If the script being called happens to have the same
        // hook call within it a loop can happen
        if ($this->_in_progress === TRUE) {
            return;
        }
        // -----------------------------------
        $class = null;
        $function = null;

        $res = $this->_checkSetting($which, $data);

        // Determine and class and/or function names
        if (isset($res['class'])) {
            $class = $res['class'];
            $function = $which;
        } else {
            $function = $res['function'];
        }

        $params = isset($data['params']) ? $data['params'] : array();

        array_unshift($params, $context);
        //-----------------------
        $returnValue = NULL;

        $this->_in_progress = TRUE;
        /*
         * Call the requested class and/or function
         * 執行 hook setting
         */

        if ((empty($class))) {
            if (is_string($function)) {

                $i = 0;
                while (!function_exists($function)) {
                    if ($i++ > 0) {
                        throw new \Exception(sprintf('hook(%s) file(%s), function(%s) no exists', $which, $res['filename'], $function));
                    }
                    require_once($res['filename']);
                }
            }

            // 執行
            $returnValue = call_user_func_array($function, $params);
        } else {

            $index = fun\key_checkClassName($class, true);
            $index = strtolower($index);

            // The object is stored?
            if (!isset($this->_hook_instance[$index])) {

                $i = 0;
                while (!class_exists($class)) {
                    if ($i++ > 0) {
                        throw new \Exception(sprintf('hook(%s) file(%s), class(%s) no exists', $which, $res['filename'], $class));
                    }
                    require_once($res['filename']);
                }

                // Store the object and execute the method
                $this->_hook_instance[$index] = new $class();
            }

            $actionObj = $this->_hook_instance[$index];

            if (!method_exists($class, $function)) {
                throw new \Exception(sprintf('hook(%s) file(%s), %s->%s() no exists', $which, $filepath, $class, $function));
            }
            //------------------
            \get_container($actionObj);

            // 執行
            $returnValue = call_user_func_array(array($actionObj, $function), $params);
            
            \get_container(null);
            
        }

        $this->_in_progress = FALSE;
        return $returnValue;
    }

    // -------------------------------------------------------------------------

    /**
     * 載入所需的 class
     */
    protected function _checkClass() {

        $class = SYS_ROOT_NAMESPACE . 'hook\\CI_Hook';
        if (!class_exists($class)) {
            $file = BASEPATH . 'core1/Hook/Hook.php';
            \include_class($file, $class, TRUE);
        }

        $class = SYS_ROOT_NAMESPACE . 'hook\\CI_Hook_context';
        if (!class_exists($class)) {
            $file = BASEPATH . 'core1/Hook/Hook_context.php';
            \include_class($file, $class, TRUE);
        }
    }

    // -------------------------------------------------------------------------

    /**
     * 取得 hookscope
     */
    protected function &_get_context($which) {
        $index = strtolower($which);

        $file = ucfirst($which);
        $class = fun\coreConfig('hook.context_namespace') . 'CI_' . $file;

        if (isset($this->contexts[$index])) {
            // scope 也是屬於單例
            return $this->contexts[$index];
        }
        //------------------
        // 載入 context class
        $file_exists = FALSE;

        if (!class_exists($class)) {
            $hook_context_dir = fun\coreConfig('hook.context_class_dir');

            if(!is_array($hook_context_dir)){
                $hook_context_dir = array($hook_context_dir);
            }

            console()->dump($hook_context_dir);

            foreach ($hook_context_dir as $dir) {
                $fileName = $dir . $file . '.php';
                if (file_exists($fileName)) {
                    $file_exists = TRUE;
                    require_once($fileName);
                    break;
                }
            }
        }

        if (!$file_exists) {
            throw new \Exception(sprintf('scope(%s) file no exists', $class));
        }

        if (!class_exists($class)) {
            throw new \Exception(sprintf('scope class(%s) no exists', $class));
        }
        $this->contexts[$index] = new $class();

        return $this->contexts[$index];
    }

    // -------------------------------------------------------------------------

    /**
     * 根據檔案結構取得 namespace
     * 
     * @param type $fileName
     */
    protected function _get_hook_namespace($fileName) {
        $fileName = str_replace('/', '\\', $fileName);

        $dir = '';

        // 取出 dir
        $last_slashe = strrpos($fileName, '\\');
        if ($last_slashe !== false) {
            $dir = substr($fileName, 0, ++$last_slashe);
        }
        // -----------------------------------
        // check namespace
        $namespace = fun\coreConfig('hook.container_namespace');
        $namespace = $namespace . $dir;

        return $namespace;
    }

    // -------------------------------------------------------------------------

    /**
     * 檢查使用者的 hook setting
     * 
     * @param type $setting
     * @return string
     * @throws \Exception
     */
    protected function _checkSetting($which, $setting) {

        $res = array();

        if (is_callable($setting)) {

            if (is_array($setting)) {
                // array($object, 'method')不支持這種模式 
                throw new \Exception(sprintf('no support such hook setting type(%s)', json_encode($setting)));
            } else {
                $res['function'] = $setting;
            }
        } else if (isset($setting['class']) || isset($setting['function'])) {
            /*
             * class or function
             */

            // check file
            $fileName = @$setting['filename'];

            if (empty($setting['filename'])) {
                throw new \Exception(sprintf('hook setting(%s) no set filename', json_encode($setting)));
            }

            $fileName = ltrim($fileName, '\\/');

            // 檢查檔案是否存在
            $hook_setting_dir = fun\coreConfig('hook.hook_class_dir');
            $filepath = $hook_setting_dir . $fileName;

            if (!file_exists($filepath)) {
                throw new \Exception(sprintf('hook(%s) file(%s) no exists', $which, $filepath));
            }

            $res['filename'] = $filepath;
            //----------------------------
            if (isset($setting['class'])) {

                $class = $setting['class'];

                if (!preg_match('/\\\\/', $class)) {
                    // 若使用者沒設置 namespace
                    $namespace = $this->_get_hook_namespace($fileName);
                    $class = $namespace . $class;
                }
                $res['class'] = $class;
            } else if (isset($setting['function'])) {

                $function = $setting['function'];

                if (!preg_match('/\\\\/', $function)) {
                    // 若使用者沒設置 namespace
                    $namespace = $this->_get_hook_namespace($fileName);

                    console()->log('namespace(%s)', $namespace);

                    $function = $namespace . $function;
                }
                $res['function'] = $function;
            }
        } else {
            throw new \Exception(sprintf('hook setting(%s) no set class or function', json_encode($setting)));
        }

        console()->log('hook res(%s)', json_encode($res));

        return $res;
    }

}
