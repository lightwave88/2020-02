<?php

namespace ci\system;

use ci\system\fun;

/**
 * 全域類別
 */
class CI_Library_loader {

    const Lib_root_dir = 'libraries\\';

    protected static $instance;

    /**
     * libs 的單例
     *
     * @var array
     */
    protected static $_ci_single_libs = array();

    /**
     * core 的單一實例
     *
     * @var type
     */
    protected static $_ci_single_cores = array();

    /**
     * 記錄注入的 class
     */
    protected static $_ci_lib_inject_classes = array();

    /**
     * 為了小寫辨識而設
     * (小寫 => 原命名)
     */
    protected static $_ci_lib_map = array();

    /**
     * lib 是否能注入
     * 
     * @var type 
     */
    protected static $_ci_can_inject = FALSE;

    //--------------------------------------------------------------------------

    private function __construct() {

        $class = '\Lib';
        if (false && !class_exists($class)) {
            /**
             * 新 library 要用的
             */
            $file = BASEPATH . 'core1/global_var/VAR_lib.php';
            \include_class($file, $class, TRUE);
            $class::get_instance($this);
        }

        $class = SYS_ROOT_NAMESPACE . 'CI_Library';
        if (!class_exists($class)) {
            /**
             * 新 library 要用的
             */
            $file = BASEPATH . 'core1/Library.php';
            \include_class($file, $class, TRUE);
        }
    }

    //--------------------------------------------------------------------------
    public function &load($muduleName, $params = NULL, $single = TRUE) {
        // Console()->log('load(%s)', $muduleName);

        $lib = &self::_load_lib($muduleName, $params, $single);

        $varName = fun\key_getModuleVarName($muduleName);

        if (!isset($this->$varName) || $this->$varName !== $lib) {
            self::$_ci_can_inject = TRUE;
            $this->$varName = $lib;
            self::$_ci_can_inject = FALSE;
        }

        return $lib;
    }

    //--------------------------------------------------------------------------
    public function bind($container, $muduleName, $params = NULL, $name = NULL, $single = TRUE) {

        if (isset($container->load) && is_a($container->load, (SYS_ROOT_NAMESPACE . 'CI_Loader_ABS'))) {
            /*
             * 若該物件有 loader 模組
             * 用 loader 模組載入
             */
            $lib = &$container->load->lib($muduleName, $params, $name, $single);
        } else {
            // 若該物件沒有 loader 模組

            $varName = fun\key_getModuleVarName($muduleName);
            $lib = &self::_load_lib($muduleName, $params, $single);

            if (isset($container->$varName) && $container->$varName === $lib) {
                return;
            }

            $container->$varName = &$lib;
        }
        return $lib;
    }

    //--------------------------------------------------------------------------

    /**
     * 注入一個 class
     * 不按照既有規則
     */
    public function load_class($nickName, callable $callback) {

        $nickName = strtolower($nickName);

        $_ci_lib_classes = &self::$_ci_lib_inject_classes;

        if (isset($_ci_lib_classes[$nickName])) {
            return $_ci_lib_classes[$nickName];
        }

        $className = $callback();

        if (!class_exists($className)) {
            throw new \Exception("no class $className");
        }
        self::$_ci_lib_inject_classes[$nickName] = $className;

        return $className;
    }

    //--------------------------------------------------------------------------
    public function is_loaded($moduleName = NULL) {

        if (!is_null($moduleName)) {
            if (preg_match('/.+::class$/', $moduleName)) {
                $index = fun\key_checkClassName($moduleName);
            } else {
                $list = fun\key_checkModuleName($moduleName);
                $index = empty($list[0]) ? $list[1] : sprintf('%s\\%s', $list[0], $list[1]);
                $index = strtolower($index);
            }
        }
        return self::_is_loaded($moduleName);
    }

    //--------------------------------------------------------------------------
    public function __set($name, $value) {
        if (!self::$_ci_can_inject) {
            return;
        }

        if (method_exists($this, $name)) {
            return;
        }

        $this->$name = $value;
    }

    //--------------------------------------------------------------------------

    /**
     * for test
     */
    public function test() {
        $class = SYS_ROOT_NAMESPACE . 'CI_Library_loader';
        return get_class_vars($class);
    }

    //--------------------------------------------------------------------------
    public static function &get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    //--------------------------------------------------------------------------
    public static function &get_static_var($var) {
        return self::$$var;
    }

    //--------------------------------------------------------------------------

    /**
     * 詢問
     */
    public static function _is_loaded($index = NULL) {
        $_ci_lib_map = &self::$_ci_lib_map;

        if (empty($index)) {
            return $_ci_lib_map;
        }
        return (isset($_ci_lib_map[$index]) ? $_ci_lib_map[$index] : FALSE);
    }

    //--------------------------------------------------------------------------

    /**
     * 
     * @param type $className: [模組名稱|$class全名]
     * @param type $direct: [core|libraries]
     * @return [boolean|array()]
     */
    public static function _has_loaded($index, $moduleName) {

        $_ci_lib_map = &self::$_ci_lib_map;
        $_ci_lib_map[$index] = $moduleName;
    }

    //--------------------------------------------------------------------------

    /**
     * 多為 core1 用
     *
     * @param type $className
     * @param type $path
     * @param array $param
     * @param type $single
     * @return type
     */
    public static function &load_system_class($class, $path, $param = array(), $single = TRUE) {
        console()->log($class);

        $single = !!$single;

        if (!is_array($param)) {
            $param = array();
        }

        $_classes = &self::$_ci_single_cores;

        $className = fun\key_checkClassName($class, TRUE);

        if ($single) {
            $m_name = self::_is_loaded($className);

            if (!empty($m_name)) {
                return $_classes[$m_name];
            }
        }
        //------------------
        $i = 0;
        while (!class_exists($class)) {
            if ($i < 1) {
                if (!file_exists($path)) {
                    $error = sprintf('no file %s', $path);
                    throw new \Exception($error);
                }
                require_once($path);
            } else {
                $error = sprintf('no class %s', $className);
                throw new \Exception($error);
            }
            $i++;
        }
        //------------------        
        // 實例化 library
        $instance = &\instance_class($class, $param);

        if ($single == TRUE) {
            $class = get_class($instance);
            $class = fun\key_checkClassName($class, TRUE);

            self::_has_loaded($class, $class);
            $_classes[$class] = &$instance;
        }
        return $instance;
    }

    //--------------------------------------------------------------------------

    public static function &load_lib($class, $param = NULL, $single = TRUE) {
        return self::_load_lib($class, $param, $single);
    }

    //--------------------------------------------------------------------------

    /**
     * 把 load_class() 導到此處
     * core, library 約定俗成的(單例 instance)方式
     *
     *
     * @param type $class
     * @param type $directory
     * @param type $param
     * @param type $single: 是否是單例
     * @return type
     */
    public static function &load_core_class($class, $directory = 'libraries', $param = NULL) {
        // Console()->log('load_system_class(%s)', $class);

        $single = TRUE;

        $directory = trim($directory, '/\\');

        $instance = NULL;

        if (preg_match('/^core$/', $directory)) {
            $instance = &self::_load_core($class, $param, $single);

            $varName = fun\key_getModuleVarName($class);

            $CI = &get_instance();

            if (!isset($CI->$varName)) {
                fun\container_load_core($CI, $class, $instance);
            }
        } else {
            $instance = &self::_load_lib($class, $param, $single);
        }
        //-----------------------

        return $instance;
    }

    //--------------------------------------------------------------------------

    /**
     * core 因為沒有對外公開
     * 所以不需要複雜的子目錄結構
     *
     *
     * @param type $class
     * @param type $param
     * @param type $single
     * @return type
     */
    protected static function &_load_core($class, $param, $single) {
        $single = !!$single;

        $prefix = config_item('subclass_prefix');

        $list = fun\key_checkModuleName($class);
        $moduleName = $list[1];

        $indexName = empty($list[0]) ? $list[1] : sprintf('%s\\%s', $list[0], $list[1]);
        $indexName = strtolower($indexName);
        //-----------------------

        $_classes = &self::$_ci_single_cores;

        if ($single) {
            $m_name = self::_is_loaded($indexName);

            if (!empty($m_name)) {
                $m_name = strtolower($m_name);
                return $_classes[$m_name];
            }
        }
        //-----------------------
        // 系統可能的位置

        $pathList = array();

        $pList = array(
            '',
            ($class . '\\')
        );

        $fileName = $class . '.php';

        // 會放置 core 的目錄
        $core_dirs = fun\coreConfig('core.module_dir');

        // array(APPPATH, BASEPATH)
        foreach ($core_dirs as $dir) {
            foreach ($pList as $d) {
                $pathList[] = $dir . $d . $fileName;
            }
        }
        //-----------------------
        // 尋找系統檔
        $className = NULL;

        $namespace = SYS_ROOT_NAMESPACE;

        $index = NULL;
        foreach ($pathList as $k => $file) {
            if (file_exists($file)) {
                $index = $k;
                require_once($file);
                break;
            }
        }

        if (!isset($index)) {
            throw new \Exception(sprintf('core(%s) file no exists', $moduleName));
        }

        $className = $namespace . 'CI_' . $class;
        if (!class_exists($className)) {
            throw new \Exception(sprintf('core(%s) class(%s) no exists', $moduleName, $className));
        }
        //-----------------------
        // 尋找是否有使用者的擴充
        if ($index > 1) {
            $index = $index % 2;

            $fileName = $prefix . $class . '.php';
            $file = $pathList[$index] . $fileName;

            if (file_exists($file)) {
                require_once($file);
                $className = $namespace . $prefix . $class;

                if (!class_exists($className)) {
                    throw new \Exception(sprintf('core(%s) class(%s) no exists', $moduleName, $className));
                }
            }
        }
        //-----------------------
        $inctance = isset($param) ? new $className($param) : new $className();

        if ($single) {
            // 單例需要登錄
            self::_has_loaded($indexName, $moduleName);

            $_classes[$indexName] = &$inctance;

            // 修改過的地方
            // 記錄完整的 className
            $className = get_class($inctance);
            $className = fun\key_checkClassName($className, TRUE);

            if (isset($_classes[$className]) && $_classes[$className] === $inctance) {
                // 若 class 曾被實例化
                $inctance = &$_classes[$className];
            } else {
                self::_has_loaded($className, $moduleName);
                // $_classes[$className] = &$inctance;
            }
        }
        //------------------
        return $inctance;
    }

    //--------------------------------------------------------------------

    /**
     * lib 是公開給使用者
     * 所以會有複雜子目錄，方便使用者組織
     *
     * @param type $lib
     * @param type $param
     * @param type $single
     * @return \system\libraries
     */
    protected static function &_load_lib($lib, $param = NULL, $single = TRUE) {

        $single = !!$single;

        $list = fun\key_checkModuleName($lib);

        $indexName = empty($list[0]) ? $list[1] : sprintf('%s\\%s', $list[0], $list[1]);
        $indexName = strtolower($indexName);

        $_classes = &self::$_ci_single_libs;

        if ($single) {
            $m_name = self::_is_loaded($indexName);
            if (!empty($m_name)) {
                $m_name = strtolower($m_name);
                return $_classes[$m_name];
            }
        }
        //------------------
        // 確定是否有子目錄
        // 子目錄
        $subdir = $list[0];
        $lib = $list[1];
        $lib_config_file = $lib;
        //------------------
        // 載入檔案

        $checkConfig = TRUE;

        $className = self::_load_inject_class($lib_name);

        if (empty($className)) {
            $className = self::_load_stock_lib($subdir, $lib);
        } else {
            $checkConfig = FALSE;
        }

        if (empty($className)) {
            $className = self::_ci_load_user_lib($subdir, $lib);
        }

        if (empty($className)) {
            throw new \Exception(sprintf('lib(%s) class undefined', $lib_name));
        }

        if (!class_exists($className)) {
            throw new \Exception(sprintf('lib(%s) class(%s) undifined', $lib_name, $className));
        }
        //-----------------------
        // 檢查是否有相關的 config 文件

        $core_config = load_class('Config', 'core');

        if ($checkConfig && is_array($core_config->_config_paths)) {
            $configFileList = array();

            $fileName_1 = strtolower($lib_config_file) . '.php';
            $fileName_2 = ucfirst(strtolower($lib_config_file)) . '.php';

            $basePath = 'config/libraries/' . $subdir;
            $configFileList[] = $basePath . $fileName_1;
            $configFileList[] = $basePath . $fileName_2;

            $basePath = 'config/' . ENVIRONMENT . '/libraries/' . $subdir;
            $configFileList[] = $basePath . $fileName_1;
            $configFileList[] = $basePath . $fileName_2;

            foreach ($core_config->_config_paths as $path) {
                foreach ($configFileList as $_path) {
                    $file = $path . $_path;

                    if (file_exists($file)) {
                        include($file);
                    }
                }
            }
        }

        if (isset($config)) {
            if (!is_array($config)) {
                $config = array();
            }
        } else {
            $config = array();
        }


        if (is_array($param)) {
            $config = array_merge($config, $param);
        }
        //-----------------------
        $instance = isset($config) ? new $className($config) : new $className();

        if (is_a($instance, (SYS_ROOT_NAMESPACE . 'CI_Library'))) {
            // 新 library 的執行方式
            // 避免模組相互依賴的問題
            $instance->initialize();
        }

        if ($single) {
            self::_has_loaded($indexName, $lib_name);

            $_classes[$indexName] = &$instance;

            $className = get_class($instance);
            $classNamee = fun\key_checkClassName($className, TRUE);

            if (isset($_classes[$className]) && $_classes[$classNamee] === $instance) {
                $instance = &$_classes[$classNamee];
            } else {
                self::_has_loaded($classNamee, $lib_name);
                // $_classes[$classNamee] = &$instance;
            }
        }
        //------------------
        return $instance;
    }

    //--------------------------------------------------------------------

    /**
     * 使用者自己注入的 class
     */
    protected static function _load_inject_class(&$moduleName) {
        $index = strtolower($moduleName);

        $className = null;

        if (isset(self::$_ci_lib_inject_classes[$index])) {
            $className = self::$_ci_lib_inject_classes[$index];
            $moduleName = $index;
        }

        return $className;
    }

    //--------------------------------------------------------------------

    /**
     * 系統預設的 lib
     *
     * @param type $subdir
     * @param type $class
     * @return type
     */
    protected static function _load_stock_lib($subdir, $lib) {

        $lib = ucfirst($lib);

        // class 不存在
        // load file        

        $className = NULL;

        //------------------
        $pathList = array();

        $pathList[] = $subdir;

        // lib 比較複雜，無法只用一個檔案組成
        $pathList[] = $subdir . $lib . '\\';

        //------------------
        $fileName = $lib . '.php';

        $lib_sys_file = NULL;

        // 檢查 BASEPATH/libraries
        $i = NULL;
        foreach ($pathList as $k => $dir) {

            $file = BASEPATH . self::Lib_root_dir . $dir . $fileName;
            if (file_exists($file)) {
                $lib_sys_file = $file;
                $i = $k;
                break;
            }
        }
        //------------------
        if (!isset($lib_sys_file)) {
            // 沒有系統的 lib
            return NULL;
        }
        //------------------
        // 檢查是否有覆蓋原系統的 lib
        $lib_replace_sys_file = NULL;

        $j = NULL;
        foreach ($pathList as $k => $dir) {
            $file = APPPATH . self::Lib_root_dir . $dir . $fileName;
            if (file_exists($file)) {
                $lib_replace_sys_file = $file;
                $j = $k;
                require_once($lib_replace_sys_file);
                break;
            }
        }
        if (isset($lib_replace_sys_file)) {
            $className = self::_ci_checkLib_namespace($pathList[$j], $lib, 'CI_');
            if (!isset($className)) {
                _load_stock_lib_error($lib, $lib_replace_sys_file, $className);
            }
            return $className;
        }
        //------------------
        // 沒有覆蓋原系統的 lib

        require_once($lib_sys_file);

        $className = self::_ci_checkLib_namespace($pathList[$i], $lib, 'CI_');

        if (!isset($className)) {
            _load_stock_lib_error($lib, $lib_sys_file, $className);
        }
        //------------------
        // 是否有擴展

        $lib_extend_sys_file = NULL;

        $prefix = \config('subclass_prefix');
        $fileName = $prefix . $lib . '.php';

        $n = NULL;
        foreach ($pathList as $k => $dir) {
            $file = APPPATH . self::Lib_root_dir . $dir . $fileName;
            if (file_exists($file)) {
                $lib_extend_sys_file = $file;
                $n = $k;
                require_once($lib_extend_sys_file);
                break;
            }
        }

        if (isset($lib_extend_sys_file)) {
            $className = self::_ci_checkLib_namespace($pathList[$n], $lib, $prefix);
            if (!isset($className)) {
                _load_stock_lib_error($lib, $lib_replace_sys_file, $className);
            }
        }

        return $className;
    }

    //--------------------------------------------------------------------------

    /**
     * 使用者寫的 lib
     *
     * @param type $subdir
     * @param type $class
     */
    protected static function _ci_load_user_lib($subdir, $lib) {

        $lib = ucfirst($lib);

        $res = NULL;
        //------------------
        $pathList = array();

        $pathList[] = $subdir;
        $pathList[] = $subdir . $lib . '\\';

        $fileName = $lib . '.php';
        $loadFile = NULL;

        foreach ($pathList as $dir) {
            $loadFile = APPPATH . self::Lib_root_dir . $dir . $fileName;

            if (file_exists($loadFile)) {
                require_once($loadFile);
                $class = self::_ci_checkLib_namespace($subdir, $moduleName);
                if (!isset($className)) {
                    throw new \Exception(sprintf('library(%s) file(%s) exists, but class(%s) undefined', $lib, $loadFile, $class));
                }
                $res = $class;
                break;
            }
        }
        return $res;
    }

    //--------------------------------------------------------------------------

    /**
     * lib 有可能有兩種 namspace
     * 一種 全域 namespace(預設)
     * 一種 新增的 \libraries\
     *
     * @param type $subdir
     * @param type $moduleName
     * @param type $prefix
     * @return string
     */
    protected static function _ci_checkLib_namespace($subdir, $moduleName, $prefix = '') {
        $namespace = array();

        $lib_namespace = config('library_namespace');
        $lib_namespace = trim($lib_namespace, '/\\');

        $namespace[] = '\\' . $lib_namespace . '\\' . $subdir;
        $namespace[] = '\\';
        $res = NULL;


        $className = $prefix . $moduleName;
        foreach ($namespace as $value) {
            $class = $value . $className;
            if (class_exists($class)) {
                $res = $class;
                break;
            }
        }

        return $res;
    }

    //--------------------------------------------------------------------------
}

function _load_stock_lib_error($lib, $file, $class) {
    $errorMsg = sprintf('library(%s) file(%s) exists, but class(%s) undefined'
            , $lib, $file, $class);
    throw new \Exception($errorMsg);
}
