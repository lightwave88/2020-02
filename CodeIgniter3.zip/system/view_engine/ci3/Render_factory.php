<?php

namespace ci\system\view\ci3;

/**
 * 提供 view render 最單純的環境
 */
class Render_factory {

    /**
     * context
     * 
     * @var type 
     */
    protected $_ci_view_core;

    /**
     * 記錄 view 的內容
     * 
     * @var type 
     */
    protected $_ci_view_result = '';

    /**
     * Render_action
     * 
     * @var type 
     */
    protected $_ci_parent;

    /**
     * 頁面的資料
     * 
     * @var type 
     */
    protected $_ci_pageData = array(
        'id' => null,
        'extend' => null,
        'sections' => array(),
        'nesting' => array()
    );

    //--------------------------------------------------------------------------
    public function __construct($parent, array $options = array()) {
        $this->_ci_parent = $parent;
        $page_data = &$this->_ci_pageData;

        $context = $options['context'];
        $this->_ci_view_core = $context;

        $page_data['id'] = $options['id'];

        $data = array();

        $data['vars'] = @$options['vars'];
        $data['file'] = @$options['file'];
        $data['prev_ob_level'] = @$options['ob_level'];

        if (!is_array($data['vars'])) {
            throw new \Exception('ci3 render_factory no set vars');
        }

        if (empty($data['file'])) {
            throw new \Exception('ci3 render_factory no set file');
        }

        if (!is_int($data['prev_ob_level'])) {
            throw new \Exception('ci3 render_factory no set o_level');
        }

        $this->_ci_view_result = $this->_render($data);
    }

    public function renderSection($areaName) {
        
    }

    public function extend() {
        
    }

    public function section() {
        
    }

    public function endSection() {
        
    }

    protected function element($element_name, array $vars = null) {
        
    }

    protected function _render($_ci_view_data) {
        extract($_ci_view_data['vars']);
        /*
         * Buffer the output
         *
         * We buffer the output for two reasons:
         * 1. Speed. You get a significant speed boost.
         * 2. So that the final rendered template can be post-processed by
         * 	the output class. Why do we need post processing? For one thing,
         * 	in order to show the elapsed page load time. Unless we can
         * 	intercept the content right before it's sent to the browser and
         * 	then stop the timer it won't be accurate.
         */
        ob_start();
        // If the PHP installation does not support short tags we'll
        // do a little string replacement, changing the short tags
        // to standard PHP echo statements.
        if (!is_php('5.4') && !ini_get('short_open_tag') && config_item('rewrite_short_tags') === TRUE) {
            echo eval('?>' . preg_replace('/;*\s*\?>/', '; ?>', str_replace('<?=', '<?php echo ', file_get_contents($_ci_view_data['file']))));
        } else {
            // include() vs include_once() allows for multiple views with the same name
            // 最大的重點
            // 將 view 限制在這區塊
            include($_ci_view_data['file']);
        }
        //-----------------------
        $page_data = $this->_ci_pageData;

        if (count($page_data['sections']) > 0 || !is_null($page_data['extend'])) {
            // layout.child
            return;
        }
        //-----------------------
        // log_message('info', 'File loaded: ' . $_view_path);

        $buffer = null;
        /*
         * Flush the buffer... or buff the flusher?
         *
         * In order to permit views to be nested within
         * other views, we need to flush the content back out whenever
         * we are beyond the first level of output buffering so that
         * it can be seen and included properly by the first included
         * template and any subsequent ones. Oy!
         */
        if (ob_get_level() > $_ci_view_data['prev_ob_level'] + 1) {
            /*
             * 被套嵌的 view
             * 直接輸出
             */
            ob_end_flush();
        } else {
            $buffer = ob_get_contents();
            @ob_end_clean();
        }
        return $buffer;
    }

    //--------------------------------------------------------------------------
    public function getResult() {
        return $this->_ci_view_result;
    }

    //--------------------------------------------------------------------------
    public function __get($name) {
        return $this->_ci_view_core->$name;
    }

    //--------------------------------------------------------------------------
    public function __isset($name) {
        return isset($this->_ci_view_core, $name);
    }

}
