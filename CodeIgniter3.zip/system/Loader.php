<?php

class CI_Loader {
    
}
