
class A_error extends Error {
    constructor(msg) {
        super(msg);
    }
}

function x(i) {
    debugger;

    switch (i) {
        case 1:
            throw new A_error('1');
            break;
        default:
            throw new Error('2');
            break;
    }
}

let i = 0;

while (2 > i++) {
    debugger;

    try {
        x(i);
    } catch (e) {
        if (e instanceof A_error) {
            console.log(`A_error ${e}`);
        } else {
            console.log(`general error ${e}`);
        }
    }
}





