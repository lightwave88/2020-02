const $util = require('util');
const $fs = require('fs');
const $path = require('path');


debugger;
let path = $path.resolve('.', './template/action_1c.jsp');

const $template = require('_template3');

// console.log($util.inspect(content));
console.log('--------------------');
debugger;


$template.compile({
    file: path,
    sync: true
});


