const reg_1 = /^\S{1,}(.*)/;

const reg_2 = /([^=\s]+)\s*=\s*(["'])(.*?)\2|(\S{1,})\s*(?=\S|$)/;

const $tool = {};

{
    // 避免碰到 ">" '\>' 這類問題
    const $reg_1 = /(["']).{0,}?\1|(\/?)(>)/;

    // 取出 tag中的 attribute
    const $reg_2 = /([^=\s]+)\s*=\s*(["'])(.*?)\2|(\S{1,})\s*(?=\S|$)/;

    $tool.find_tagContentEnd = function (content) {
        debugger;

        const attributes = {};

        const reg_1 = RegExp($reg_1, 'u');

        let remain = content;
        let tag_content, is_end, checked_index;
        let find_times = 0;
        //------------------

        let lastIndex = 0;
        let res;
        while ((res = reg_1.exec(remain)) != null) {
            debugger;

            find_times++;

            let {
                0: match,
                3: find,
                index
            } = res;

            is_end = !!res[2];

            if (find == null) {
                // 進入 "", '' 區塊
                lastIndex = lastIndex + index + match.length;
                remain = content.substring(lastIndex);
                continue;
            }

            checked_index = lastIndex + index;

            // find
            tag_content = content.substring(0, checked_index);
            getAtrributes(tag_content, attributes);

            break;
        } // endWhile

        //------------------

        if (find_times) {

            return {
                content: tag_content,
                index: checked_index,
                is_end,
                attributes
            };
        }

        return null;
    }

    // 取出 tagContent 內的
    function getAtrributes(content, attributes) {
        debugger;

        const reg_1 = RegExp($reg_2, 'g');

        let res;

        while ((res = reg_1.exec(content)) != null) {
            let {
                1: key,
                3: value,
                4: key_1
            } = res;

            if (key) {
                attributes[key] = value;
            } else if (key_1) {
                attributes[key_1] = '';
            }
        } // endWhile

    }
}

let data = [
    `<div class="xyz ccc"  async id="div_1">`,
    `<div class="xyz ccc"  id="div_1" async>`
];

data.forEach((v) => {
    t1(v);
});

function t1(content) {
    debugger;

    let res;

    res = reg_1.exec(content);

    ({ 1: content } = res);

    res = $tool.find_tagContentEnd(content);

    debugger;

    console.dir(res);
}





