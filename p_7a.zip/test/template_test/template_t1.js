debugger;
const $util = require('util');
const $fs = require('fs');
const $path = require('path');

const test_fun = require('_template2');

let path = $path.resolve(__dirname, '../template/temp_11a.html');

console.log(path);

let content = $fs.readFileSync(path, {encoding:'utf8'});

// console.log($util.inspect(content));
console.log('--------------------');
debugger;
let nodeList = test_fun(content);

console.log($util.inspect(nodeList));
