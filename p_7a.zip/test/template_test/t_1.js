
function x(base_url, Page, Out) {
    Out.print(`<!DOCTYPE html>\r\n<html lang="en">\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r\n    <meta http-equiv="X-UA-Compatible" content="ie=edge">\r\n    <title>Document</title>\r\n</head>\r\n<body>\r\n    `);
    Page.require({
        "page": ("" + (base_url) + "/xyz.js"),
    });
    eval(Page.requireContent);
    Out.print(`\r\n</body>\r\n</html>\r\n`);;
}

const out = {
    print(content) {
        console.log(content);
    }
};

const page = {
    requireContent: '',
    require(options) {
        debugger;
        let { page } = options;

        let out = JSON.stringify(`page=${page}`);

        this.requireContent = `
        debugger;
        Out.print(${out});`;
    }
}

x('www/ggyy', page, out);