const $util = require('util');
const $fs = require('fs');
const $path = require('path');



let str = `0123456789`;

let reg = /.{2}/g;



let res;
while ((res = reg.exec(str)) != null) {
    debugger;
    let {index} = res;
    let next_index = reg.lastIndex;
    console.log("%s, %s", str[index], str[next_index]);
    console.dir(res);
}





