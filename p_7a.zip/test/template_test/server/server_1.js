const $fs = require("fs");
const $path = require("path");
const $http = require("http");


$http.createServer($server).listen(8082);

async function $server($req, $res) {
    $res.writeHead(200, {
        "Content_type": "text/html"
    });

    let content;
    content = readContent();

    $res.end(content);
}
//----------------------------

function readContent() {
    debugger;

    const o = require("_template3");

    let path = $path.resolve(__dirname, 'file.txt');
    let content = $fs.readFileSync(path, "utf8");
    content = content.trim();

    path = $path.resolve('.', content);
    content = $fs.readFileSync(path, "utf8");

    content = o.compile({
        content: content,
        sync: true
    });

    return content;
}