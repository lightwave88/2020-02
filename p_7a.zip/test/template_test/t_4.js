const $util = require('util');
const $fs = require('fs');
const $path = require('path');

let i = 0;
do {
    debugger;
    let condition = (i++ > 3) ? false : true;
} while (condition);