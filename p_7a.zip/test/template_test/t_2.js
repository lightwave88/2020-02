const $util = require('util');
let a = 7;

let strList = [
    'xyz<%= a*5 %>abc',
    '<%= a*5 %>abc',
    '"gg"<%= a*5 %>"aa"'
];


function t_1(content) {
    
    content = content.replace(/([\s\S]*?)<%[-=]([\s\S]*?)%>/g, (m, g1, g2) => {
        let res = JSON.stringify(g1) + `<%${g2}%>`;
        return res;
    });

    
    content = content.replace(/(<%[\s\S]*?%>)([\s\S]*?)$/g, (m, g1, g2) => {
        let res = g1 + JSON.stringify(g2);
        return res;
    });

  
    content = content.replace(/<%([\s\S]*?)%>/g, (m, g1) => {
        let res = '+(' + g1.trim() + ')+';
        return res;
    });

    return content;
}

strList.forEach((str) => {
    // return;
    let res = t_1(str);

    // res = res.replace(/[^\\]?"/g, '\"');

    console.log($util.inspect(res));
    res = eval(res);
    console.log(res);
    console.log('------------');
});

