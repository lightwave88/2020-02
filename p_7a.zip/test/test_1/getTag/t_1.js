const $util = require('util');
const {findTags, getFileContent, rootPath} = require('getTag');


let path = `${rootPath}/template/temp_3.html`;
let content = getFileContent(path);

// console.log(content);


let nodeList = findTags(content);


console.log('-----------------');
console.log($util.inspect(nodeList));

