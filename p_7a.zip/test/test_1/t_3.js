const _ = require('underscore');

let res = require.resolve(_);

console.log(res);