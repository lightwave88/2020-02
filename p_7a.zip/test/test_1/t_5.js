const $util = require('util');

let reg = /<%([\s\S]*?)%>/i;



let str = `</div>\n <% for(let i=0; i < x.length; i++){ %>`;
check(str);

str = `<div>\n <% for(let i=0; i < x.length; i++){ <div id="a"> 555 %>`;
check(str);

str = `<div>\n <% for(let i=0; i < x.length; i++){ <div> 555 %>`;
check(str);

str = `<div>\n <% for(let i=0; i < x.length; i++){ </div> 555 %>`;
check(str);

str = `<div>\n <% for(let i=0; i < x.length; i++){ <x-yz> 555 %>`;
check(str);

function check(str){
    let res = reg.exec(str);

    console.log($util.inspect(res));
    if(res != null && res[1] != null){

        res = /(<(?:\/)?[a-z][^\s>/]{0,}[^<]*?>)/i.exec(res[1]);
        console.log($util.inspect(res));
    }
    console.log('-----------------');
}
