const $util = require('util');

class X {
    constructor() {
        debugger;

        this.fn = this.constructor;

    }

    test_1() {
        debugger;

        // this.s_test_1();
        this.fn.s_test_1();
    }


    static s_test_1() {
        console.log('class.test_1');
    }

    static get t() {
        debugger;
        console.log('x');
        return (Math.random() * 100);
    }
}


class Y extends X {

}

let y = new Y();
console.log(Y.t);