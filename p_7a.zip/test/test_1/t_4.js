class X {
    constructor(name){
        this.name = name;
        this._name = 'test';
    }
    getName(){
        console.log(`X: ${this.name}`);
    }

    static getSelf(){
        console.dir(this);;
    }
}

class Y extends X {

    constructor(name){
        super(name);
        this.age = 15;
    }
    getName(){
        debugger;

        console.log(`Y: ${this.name}`);
        super.getName();

    }
}

let y = new Y('y');

y.getName();

Y.getSelf();