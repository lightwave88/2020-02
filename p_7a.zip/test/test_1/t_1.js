const $fs = require('fs');
const $path = require('path');
const $util = require('util');

let path = $path.resolve(__dirname, './gg_1.html');


let content = $fs.readFileSync(path, 'utf8');

// console.log(content);

let reg = /<script>([\s\S]*)<\/script>/;

let res = reg.exec(content);

// console.dir(res[1]);
console.log('-------------');

let fnContent = "debugger;\n 'use strict';\n";

fnContent += res[1];

fnContent += `\n return (getClass());`;


let fn = new Function('A', fnContent);

// console.log(fn.toString());
//------------------------------------

class A {
    constructor() {
        this.name = 'A';
    }
}
//------------------------------------

res = fn(A);

console.dir(res);

console.log(typeof (res));


let o = new res();

console.log($util.inspect(o));
