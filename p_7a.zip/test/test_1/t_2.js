let y = 'ggg';

function G(){
    'use strick';
    console.log(y);
}

G();