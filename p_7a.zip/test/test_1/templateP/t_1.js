const $util = require('util');
const $path = require('path');
const $templateP = require('getTag');


let path = `${$templateP.rootPath}/template/temp_4a.html`;
let content = $templateP.getFileContent(path);


debugger;
let nodeList = $templateP(content);

console.log('-------------');
console.log($util.inspect(nodeList));
console.log('-------------');

// console.log(JSON.stringify($s.nodeList));
