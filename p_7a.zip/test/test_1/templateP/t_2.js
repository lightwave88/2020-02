const $util = require('util');
const $path = require('path');

const templateP = require('templateP');
const rootPath = templateP.rootPath;
const getFileContent = templateP.getFileContent;

let fileP = $path.resolve(`${rootPath}/template/temp_11a.html`);
let content = getFileContent(fileP);

console.log(content);

console.time('a');
let fn = templateP(content, 0);
console.timeEnd('a');

console.log('---------------------');
console.log($util.inspect(fn));
console.log('---------------------');


let res = fn({
    x: [
        { name: 'x', age: 15 },
        { name: 'y', age: 20 }
    ]
});

console.log(res);





