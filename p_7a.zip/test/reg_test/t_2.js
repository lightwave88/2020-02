const $util = require('util');
const $fs = require('fs');
const $path = require('path');

let path = $path.resolve(__dirname, './file_1.html');
let str = $fs.readFileSync(path, 'utf8');

debugger;


/**
 * [^\\]? 貪婪模式
 * 遇到 "" 會先嘗試先抓取 (") 之前的元素 [^\\] 
 * 所以 "(") 會被抓取
 * 等於 /(.|)"/
 */
let reg_1 = /([^\\]?)(")/;

/**
 * [^\\]? 模式
 * 遇到 "" 會先嘗試忽略之前的元素 [^\\]
 * 先抓取 (")
 * 等於 /(|.)"/
 */
let reg_2 = /([^\\]??)(")/;

debugger;
console.log(t_1(reg_1));
console.log('-----------');
console.log(t_1(reg_2));

function t_1(reg) {
    debugger;
    let i = 0;

    let reg_1 = RegExp(reg, 'g');

    let res_1 = str.replace(reg_1, (...args) => {
        debugger;

        let [m, g1, g2, index, all] = args;

        console.log($util.inspect(args));
        let res = $util.inspect(getRegExpContext(all, m, index));
        console.log(res);

        return (g1 + (i++));
    });
    return res_1;
}


function getRegExpContext(all, lastMatch, index) {
    // debugger;

    let j = index + lastMatch.length;
    let leftContext = all.substring(0, index);
    let rightContext = all.substring(j, all.length);

    return {
        leftContext,
        rightContext,
        lastMatch,
        end: (j - 1)
    };
}
