const $util = require('util');
const $fs = require('fs');
const $path = require('path');

let str = (`5  ${//%> }  `);

console.log(str);
