const $util = require('util');
const $fs = require('fs');
const $path = require('path');

// let path = $path.resolve(__dirname, './file_1.html');
// let str = $fs.readFileSync(path, 'utf8');
debugger;
let x = "...\"...";

let y = JSON.stringify(x);


let res = $util.inspect(y);
console.log(y);

/xyz/;

