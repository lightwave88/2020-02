const $util = require('util');
const $fs = require('fs');
const $path = require('path');

let reg = /<script(?=(>)|\b)/;

let str = `<script>`;

let res = reg.exec(str);

console.dir(res);