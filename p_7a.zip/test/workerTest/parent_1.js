const { MessageChannel, Worker } = require('worker_threads');
const $path = require('path');

const { port1, port2 } = new MessageChannel();

let path = $path.resolve(__dirname, './child_1.js')

var worker = new Worker(path, { workerData: [5, 6] });

worker.on('message', function (event) {
    console.log("Worker said : " + event.data);
});

console.log('postMsg');
worker.postMessage({
    age: 1
});


console.log('postMsg');
worker.postMessage({
    age: 2
});


setTimeout(()=>{
    console.log('終結 worker');
    worker.terminate();
}, 6000)


