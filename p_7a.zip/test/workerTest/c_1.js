const { parentPort, workerData } = require('worker_threads');
const $fs = require('fs');


const self = this;
let count = 0;

parentPort.on('message', function (e) {


    if(/^end/.test(e)){
        console.log("收到結束訊號");
        parentPort.postMessage("收到結束訊號");
        process.exit();
    }else{
        
        let index = count++;

        parentPort.postMessage(`收到工作(${index})`);
        for (let i = 0; i < 9999999999; i++) {
        }
        parentPort.postMessage(`(${index})結束工作`);

    }

});


