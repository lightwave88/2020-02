const { MessageChannel, Worker } = require('worker_threads');
const $path = require('path');
const $util = require('util');

let workerPath = $path.resolve(__dirname, './c_1.js');

let w_1 = new Worker(workerPath);


let count = 0;

let jobFn = function (e) {
    console.log("parent recieve msg %s", $util.inspect(e));

    if(count++ >= 3){
        w_1.off('message', jobFn);
    }
}


w_1.on('message', jobFn);

w_1.postMessage("ok");
w_1.postMessage("ok");
w_1.postMessage("end");

console.log("parent command end");