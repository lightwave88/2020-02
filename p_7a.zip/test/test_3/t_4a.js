let str = `123`;

console.log(str.substring(0, 0));


