debugger;
const x = require('./t_4.js');

debugger;
const y = {
    name: 'y',
    getName: function () {
        return `${this.name}=>${x.getName()}`;
    }
};

module.exports = y;

