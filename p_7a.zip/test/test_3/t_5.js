function x(str){
    return `<${str}>`;
}

let y = 'y';

let z = 'z';

let str = `--${`${y}`}--`;

console.log(str);

