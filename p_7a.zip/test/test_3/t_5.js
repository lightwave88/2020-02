
function test(a) {
    return `--${a}--`;
}

let str = `--${"xyz" + test(`==${test(`tt`)}==`) + "123"}--`;

console.log(str);




str = `  ${"}"  }.....`;


console.log(str);