
function a() {

    let txt = `
    include(Path["root"], '/nodeJs_test/t_1/html/h_2_c1.html')
    `;


    let reg = /(?:\b|;)include\(([^)]*)\)(?:\s|;)/;

    let res = reg.exec(txt);

    console.dir(res);
}


function b() {
    let txt = `
    b ) a
    `;

    let reg = /\w\b/g;
    let res = txt.match(reg);

    console.dir(res);
}

function c() {
    let txt = `
        f
    `;

    txt.replace(/\s*/, (m, i) => {
        console.log(m.length);
    })
}

function d() {
    let txt = `f
d e`;

    txt = txt.replace(/\s+/g, (m) => {
        console.log('%s, %s', m, m.length);
        return ('#' + m);
    });

    console.log(txt);
}

function e(){
    let txt = `
a`;

    txt.replace(/[\s](.)/, (m, g1)=>{
        debugger;
    });

    console.log(txt);
}

e();