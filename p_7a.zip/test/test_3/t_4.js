debugger;
const y = require('./t_4a.js');
debugger;
const x = {
    name: 'x',
    getName: function() {
        return `${this.name}=>${y.getName()}`;
    }
};

module.exports = x;

x.getName();