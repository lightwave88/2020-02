let artTemplate = require('artTemplate');
const util = require('util');

let str = `<% if (user) { %>
    <h2><%= user.name %></h2>
  <% } %>`;

let res = artTemplate.render(str, {
    user: {
        name: 'xyz'
    }
});


console.log('res(%s)', res);


