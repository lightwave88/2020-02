const $util = require("util");
// const _ = require("underscore");
// const _path = require.resolve("underscore");

// const _ = require("_extension1")("underscore");
// console.log($util.inspect(_.$extension1));




let a = {
    a: x => x + 1,
    c(a) {
        return { a: a };
    },
    d: function (a) {
        return { a: a };
    },
    e: (a) => {
        return function () {

        };
    },
    x(a) {
        return { a: a };
    },
    y: function (a) {
        return { a: a };
    },
    z: (a) => { return { a: a }; },
};
const reg_1 = /\((.*)\)(?:\s|\r|\n)*=>(?:\s|\r|\n)*{([\s\S]*)}/;
const reg_2 = /^[^(]+\((.*?)\)(?:\s|\r|\n)*{([\s\S]*)}/;

for (let k in a) {
    console.log("-----------------");
    let fn = a[k];
    console.log("is funtion(%s)", (typeof fn == "function"));

    let fnStr = fn.toString();
    console.log(fnStr);

    let res;

    res = reg_1.exec(fnStr);


    if (res == null) {
        res = reg_2.exec(fnStr);
    }

    console.log($util.inspect(res));
}
