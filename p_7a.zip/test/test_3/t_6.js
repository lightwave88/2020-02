const $util = require('util');

let a = {
    age: 15,
    name: "accb..................................>>>",
};

let b = {
    name: "accb..................................>>>",
    age: 15,
};


function plainObj_isEqual(a, b) {
    debugger;   

    a = JSON.stringify(a);
    b = JSON.stringify(b);

    return Object.is(a,b);
}

function plainObj_sort_key(a, b) {

    let a_list = Object.keys(a);
    let b_list = Object.keys(b);

    a_list = a_list.sort(_sort);
    b_list = b_list.sort(_sort);

    const a_clone = {};
    const b_clone = {};

    a_list.forEach((key) => {
        a_clone[key] = a[key];
    });

    b_list.forEach((key) => {
        b_clone[key] = b[key];
    });

    function _sort(a, b) {
        return (a.localeCompare(b));
    }
    return [a_clone, b_clone];
}

let res = plainObj_sort_key(a, b);

console.log(plainObj_isEqual(res[0], res[1]));



