const $util = require('util');

let str = "012345678";


let reg = /\d(?=\d)/g;
reg.lastIndex = 5;

let res = reg.exec(str);


console.log($util.inspect(res));
console.log(reg.lastIndex);



