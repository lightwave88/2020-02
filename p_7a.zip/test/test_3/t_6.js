const $util = require('util');

let reg_1 = /<(\/)?([^\s\/]+?)(?=(\s|>|\/))/g;

let str = `
<div>TODO write content</div>
</body>
</html>`;


console.log($util.inspect(str.match(reg_1)));


