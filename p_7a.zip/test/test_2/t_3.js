$util = require('util');

let str = '01234567890 abc';

str.replace(/(45)(.)/, function (a, b) {
    // debugger;

    // console.dir(arguments);
});


// console.dir(/(45)(.)/.exec(str));


str = `""`;
a(str);


str = `let v = 0; console.log("</script>")`;
// console.log(str);
a(str);


str = `let v = 0; </script>`;
a(str);

function a(str){
    let r = '(?:([`][\\s\\S]*?[^\\\\][`])|([\'][\\s\\S]*?[^\\\\][\'])|(["][\\s\\S]*?[^\\\\]["])|(\\/\\/[\\s\\S]*?\\\\n)|(\\/\\*[\\s\\S]*?\\*\\/)|(<\\/script>))(.*)';
    let reg = RegExp(r);

    let res = reg.exec(str);

    console.log($util.inspect(res));
}