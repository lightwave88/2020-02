
let reg = /(?:<(script)[\s>])|(?:(<%[-=]?)\s)/;
reg = /(?:<(script)[\s>])|(?:(<%[-=]?)\s)/

let x = `<div>
div
</div>
<script>
alert('hi');
</script>
<ul>
<% for(let i = 0; i <
<li>
data.length; i++){ %>

</li>
<% } %>

</ul>`;


console.dir(reg.exec(x));
