require("test1");
const $util = require('util');

function getChecIncludekReg() {
    debugger;

    let list = [];
    let reg;

    // 捕捉 ``
    list.push(/(?:[`][\s\S]*?[^\\][`])/);

    // 捕捉 ''
    list.push(/(?:['][\s\S]*?[^\\]['])/);

    // 捕捉 ""
    list.push(/(?:["][\s\S]*?[^\\]["])/);

    // 捕捉 // \n
    list.push(/(?:\/\/[\s\S]*?(?:\n|\r))/);

    // 捕捉 /* */
    list.push(/(?:\/\*[\s\S]*?\*\/)/);

    // 捕捉 include()
    list.push(/(?:\binclude\(([\s\S]*?)\)[\b;])/);

    let list_1 = [];

    list.forEach(function (v, i) {
        list_1.push(v.source);
    });

    let str = list_1.join('|');

    list = undefined;
    list_1 = undefined;

    reg = RegExp(str, 'i');

    return reg;
}

let res = getChecIncludekReg();

console.dir(res);








