const $st = require('stream');
const $util = require('util');
const $http = require('http');

const Readable = $st.Readable;
const Writable = $st.Writable;

// const $path = require('path');
// console.log($util.inspect($path));
// console.log($path.resolve(__dirname, './'));

class R extends Readable {
    constructor() {
        // this.timeHandle;
        super();
        // this.num;
    }

    async _read() {

        const $this = this;
        // this.push(null);
        let i = 0;

        while (i++ < 5000) {
            let r = this.push((i + '<br>'), 'utf8');
            console.log('(%i)(%s)', i, r);

            if (!r) {
                console.log('wait(%s)', i);
                this.pause();
                await wait();
                this.resume();
            }
        }

        this.push(null);
    }


}

function wait() {
    return new Promise(function (res, rej) {
        setTimeout(function () {
            res();
        }, 500);
    });
}


$http.createServer(function (req, res) {

    res.writeHead(200, {
        'Content-type': 'text/html'
    });

    let r = new R();

    r.pipe(res);

}).listen(8080);
