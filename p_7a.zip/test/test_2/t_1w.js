const { parentPort, workerData } = require('worker_threads');

parentPort.on('message', function(e){
    debugger;
    
    // console.dir(e);
    
    let c = e.c;
    
    let fn = new Function(c);
    let res = fn();
    
    console.log('child res = %s', res);
    // console.log('child');

    parentPort.postMessage(res);

    process.exit();
});