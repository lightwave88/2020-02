// node --experimental-worker --inspect-brk=9229 ./test_2/t_1.js
debugger;

const $path = require("path");
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

let workerPath = $path.resolve(__dirname, './t_1w.js');
const w = new Worker(workerPath);

w.on("message", function (e) {
    debugger;
    console.log('parent');
    console.dir(e);
});

debugger;
w.postMessage({ 
    a: "a" ,
    c: `return Math.floor(Math.random()*1000);`
});







