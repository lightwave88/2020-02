let reg = /<(?:\/)?([a-z][^\s>/]{0,})[\s\S]*?>/;

let str = '<x-yz id="div_1">';
console.log(reg.exec(str));


str = '<x-yz>';
console.log(reg.exec(str));

str = '<div <>';
console.log(reg.exec(str));

str = '<div class="gg">';
console.log(reg.exec(str));
