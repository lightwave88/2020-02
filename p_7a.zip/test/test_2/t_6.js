const $util = require("util");

let reg_1 = /^[^{]+\{([\s\S]*)\}[^}]*$/;


let text = `function () {
    ////////////////////////////////////////////////////////////////////////////////
    //
    // _.worker() 本體
    //
    ////////////////////////////////////////////////////////////////////////////////
    console.log('i am worker');

    console.log('href=(%s)', location.href);

    // here
    let scriptList = "@@_scriptList_@@";


    scriptList.forEach(function (scriptPath) {
        try {
            importScripts(scriptPath);
        } catch (error) {
            throw new Error('script(' + scriptPath + ')  load error');
        }
    });

    if (self._ == null) {
        throw new Error('(lodash|underscore) load error');
    }

    const $_ = self._;
    //================================================
    self.addEventListener('message', function (e) {
        // debugger;

        console.log('---------------');
        console.log('worker> get web message');

        let data = e.data || {};
        //----------------------------
        // 命令
        let command = data['command'] || '';

        // 參數
        let args = data.args || [];

        let id = data.id || 0;
        let jobID = data.jobID || null;

        //----------------------------
        // load _.script
        if ($_ == null) {
            throw new Error('(lodash|underscore) load error');
        } else {
            // worker 接運算任務
            // debugger;
            console.log('worker(%s)> do job(%s)', id, jobID);

            if (!command && typeof $_[command] != 'function') {
                throw new TypeError('_ no this function');
            }
            // debugger;
            // _ 的運算
            let res = $_[command].apply($_, args);
            //----------------------------
            self.postMessage({
                res: res
            });
        }
        console.log('---------------');
    });
    //================================================

    console.log('load ok');

    // 通知已初始化完畢
    self.postMessage({
        initialized: true
    });
}`;


let res = reg_1.exec(text);
console.log($util.inspect(res[1]));

