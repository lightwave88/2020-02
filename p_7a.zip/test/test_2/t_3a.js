$util = require('util');

let list = [];

list.push(/[`][\s\S]*?[^\\][`]/);
list.push(/['][\s\S]*?[^\\][']/);
list.push(/["][\s\S]*?[^\\]["]/);
list.push(/\/\/[\s\S]*?\\n/);
list.push(/\/\*[\s\S]*?\*\//);
list.push(/<\/script>/);


let list_1 = [];
list.forEach((v)=>{
    list_1.push(`(${v.source})`);
});

let str = list_1.join('|');
str = `(?:${str})(.*)`;

console.log(str);

let reg = RegExp(str);

console.log($util.inspect(reg.source));