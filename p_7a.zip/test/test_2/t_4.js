const $util = require('util');
const $path = require('path');

let x = { "underscore": "underscore" };

g(x);



function g(x) {

    for (let k in x) {
        x[k] = require.resolve(x[k]);
        x[k] = $path.dirname(x[k]);
    }

    console.log($util.inspect(x));
}