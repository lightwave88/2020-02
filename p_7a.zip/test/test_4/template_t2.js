debugger;
const $util = require('util');
const $fs = require('fs');
const $path = require('path');
const template = require('_template2');

let path = $path.resolve('.', './template/temp_12.jsp');
let content = $fs.readFileSync(path, {encoding: 'utf8'});

// console.log($util.inspect(content));
console.log('--------------------');
debugger;

let render_fun = template.compile({
    content: content,
    sync: true
});

let rootDir = $path.resolve('.');

debugger;
let res = render_fun({
    "base_url": (`${rootDir}/template/`)
});

console.log(res);
