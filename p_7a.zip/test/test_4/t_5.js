const $util = require('util');
const $fs = require('fs');
const $path = require('path');

let path = $path.resolve(__dirname, "./a/t_1.jsp");
let content = $fs.readFileSync(path, 'utf8');

const m = {
    name: "m....",
    print(c) {
        debugger;
        console.log(c);
    }
};

let reg = /\(([\s\S]*?)\)/g;

let list = [];

content.replace(reg, (m, g1) => {
    list.push(g1);
})

let command = 'debugger;\n';

list.forEach((v) => {
    command += "this.print(`" + v + "`);\n";
});

let fn = new Function(command);
debugger;
fn.call(m);



