const $util = require('util');

console.log(-2.23 >> 0);


