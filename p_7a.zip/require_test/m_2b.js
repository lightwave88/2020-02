debugger;

const a = require('./m_1b.js');

debugger;

module.exports = function () {
    debugger;

    console.dir(a);
}