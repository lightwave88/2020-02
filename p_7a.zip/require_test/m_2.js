debugger;

const $parent = require('./m_1.js');

debugger;

const b = {
    name: 'b',
    parent: $parent,
    getName() {
        debugger;
        return `${this.name} : ${this.parent.name}`;
    }
};

debugger;

module.exports = b;

debugger;