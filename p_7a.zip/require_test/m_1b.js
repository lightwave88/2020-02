
debugger;

const a = new Map();
module.exports = a;

debugger;

a.set('b',require('./m_2b.js'));

debugger;