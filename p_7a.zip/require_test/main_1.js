debugger;



let a = require('./m_1a.js');

debugger;
let res = a.getName();

console.log(res);