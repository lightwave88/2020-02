
debugger;

const G = require('./g.js');

if (!G.has('b')) {
    require('./m_2a.js');
}

debugger;

const a = {
    name: 'a',
    getName() {
        const $child = G.get('b')
        debugger;
        return `${this.name} => ${$child.getName()}`;
    }
};

debugger;

module.exports = a;
G.set('a', a);

debugger;