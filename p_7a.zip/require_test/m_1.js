
debugger;

const $child = require('./m_2.js');

debugger;

const a = {
    name: 'a',
    child: $child,
    getName() {
        debugger;
        return `${this.name} => ${this.child.getName()}`;
    }
};

debugger;

module.exports = a;

debugger;