debugger;

let a = require('./m_1.js');

debugger;
let res = a.getName();

console.log(res);