debugger;

const G = require('./g.js');

debugger;

if (!G.has('a')) {
    require('./m_1a.js');
}

debugger;

const b = {
    name: 'b',
    getName() {
        const $parent = G.get('a');
        debugger;
        return `${this.name} : ${$parent.name}`;
    }
};

debugger;

module.exports = b;
G.set('b', b);

debugger;