debugger;



let a = require('./m_1b.js');

debugger;

let fn = a.get('b');
fn();