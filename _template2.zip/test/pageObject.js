const GModules = require('./gmodules.js');

/**
 * 處理頁面內的系統操作
 */
class Page {
    constructor() {
        this.$$requireContent = null;
    }

    require(options) {

        let { page } = options;

        // 取得 page 的內容

        // 分析為 nodelist

        // 變成 function 內文

        $out = JSON.stringify(`(require_url=${$page})`);

        this.$$requireContent = `Out.print(${out});`
    }

    getRequire() {
        let res = this.$$requireContent;
        this.$$requireContent = null;
        return res;
    }
}

module.exports = Page;
GModules.set('Page', Output);
