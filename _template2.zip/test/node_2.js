const GModules = require('./gmodules.js');

let { node_abs } = require('./node_1.js');

const Node_ABS = node_abs;
const ACTIONNODECLASS_MAP = {};
module.exports = ACTIONNODECLASS_MAP;
GModules.set('actionNode_class', ACTIONNODECLASS_MAP);

//==============================================================================
(function () {
    class IncludeNode extends Node_ABS {
        constructor() {
            super();
        }

        printCommand() {
        }
    }

    ACTIONNODECLASS_MAP['include'] = IncludeNode;
})();
//==============================================================================
(function () {
    class RequireNode extends Node_ABS {
        constructor(tag_params, params) {
            super();
            this.tag_params = tag_params;
            this.params = params;

            this.options = this._getOptions();
        }

        _getOptions() {
            let params = Object.assign({}, this.tag_params, this.params);
            let options = '{';

            for (const key in params) {
                if (params.hasOwnProperty(key)) {
                    options += '\n' + JSON.stringify(key) + ":" + params[key] + ',';
                }
            }
            options += '}';
            return options;
        }

        printCommand() {
            let res = `Page.require(${this.options});
            eval(Page.getRequire());`;
            return res;
        }
    }

    ACTIONNODECLASS_MAP['require'] = RequireNode;
})();
//==============================================================================

(function () {
    const Reg_1 = /\(([^)]*)\)/;

    class IncludeNode extends Node {
        constructor(root, text) {
            super(root);

            this.filepPath = text;

            // 主要目標
            this.includePath;

            // 把 render 的 module.Path 引入
            // 確保同步
            this.module;

            this.systemInfo;

            // this.reg_1 = /^(?:([/\\])|[.][/\\]|[.][.][/\\])[\s\S]*$/;

            this._init();
        }
        //----------------------------
        _init() {
            this.systemInfo = $SystemInfo.getInfo();

            this.module = this.root.getModules();
        }
        //----------------------------
        _resolvePath() {
            debugger;

            if (this.module == null) {
                throw new Error('includeNode no set module');
            }

            // 預設會有 Path["root"]
            const Path = this.module.path;

            const pathSys = this.systemInfo.pathSystem;

            let fn = new Function('Path', '$path', `
                'use strict';

                debugger;
                let res = $path.join(${this.filepPath});
                return res;
            `);

            this.includePath = fn(Path, pathSys);

            console.log('includePath: %s', this.includePath);
        }
        //----------------------------
        printCommand() {
            throw new Error("include no resolve");
        }
        //----------------------------
        // 截取文件
        // 再轉成 nodeList
        // 非同步
        async include() {
            debugger;

            this._resolvePath();

            debugger;

            const fileSys = this.systemInfo.fileSystem;
            const TagTools = GModules['tagTools'];

            // 非同步取得 context
            let context = await fileSys.readFile(this.includePath);

            debugger;

            let nodeList = TagTools._getCommandTag(this.root, context);

            debugger;

            return nodeList;
        }
        //----------------------------
        // 截取文件
        // 再轉成 nodeList
        // 同步
        includeSync() {
            debugger;

            this._resolvePath();

            debugger;

            const fileSys = this.systemInfo.fileSystem;
            const TagTools = GModules['tagTools'];

            // 同步取得 context
            let context = fileSys.readFileSync(this.includePath);

            debugger;

            let nodeList = TagTools._getCommandTag(this.root, context);

            debugger;

            return nodeList;
        }
        //----------------------------
        printCommand() {
            throw new Error("IncludeNode cant be printCommand");
        }
        //----------------------------
        toString() {
            return `I(${this.url})`;
        }
    }

    return IncludeNode;
});
