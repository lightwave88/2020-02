const GModules = require('_template2/test/gmodules');

const tool = {};

module.exports = tool;
GModules.set('tool', tool);

(function () {
    tool.isset = function (obj) {
        if (typeof obj === 'undefined') {
            return false;
        }
        if (obj == null) {
            return false;
        }
        return true;
    };
    //----------------------------
    tool.empty = function (obj) {
        if (typeof obj === 'undefined') {
            return false;
        }
        if (obj == null) {
            return false;
        }
        let res = false;

        try {
            res = !Boolean(obj);
        } catch (error) {
        } finally {
            return res;
        }
    };
})();