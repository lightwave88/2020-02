const GModules = require('./gmodules.js');

if (!GModules.has('tool')) {
    require('./tool.js');
}
const $tool = GModules.get('tool');

if (!GModules.has('normalNode_class')) {
    require('./node_1.js');
}
let { nodeclass_map } = GModules.get('normalNode_class');
const NODECLASS_MAP = nodeclass_map;

if (!GModules.has('splitCommand')) {
    require('./splitCommand.js');
}
const $SplitCommand = GModules.get('splitCommand');
//---------------------

const SCRIPT_START_REG = /<(script)(?=>|\s)/;
const SCRIPT_HEAD_END_REG = /(?:<%=[\s\S]*?%>)|(?:<%-[\s\S]*?%>)|(?:<%[\s\S]*?%>)|(>)/;
const SCRIPT_END_REG = /<\/script>/;
const IS_COMMAND = /\sclass=(['"])_\1/;
/**
 * 把內文的 <script> 拆出來 *
 */
class SplitScriptTag {

    constructor(content) {
        this.content = content;

        this.prev = '';

        // 還剩下的內文
        this.left = '';

        this.head = '';
        this.body = '';
        this.foot = '';

        /*
         * 是否是 <script class="_">
         */
        this.isCommand = false;

        this.result = {
            nodeList: [],
            left: '',
        };
    }
    //--------------------------------------------------------------------------
    // API
    // 把所有的 <script> 都拆出來
    static splitAll(content) {
        debugger;

        let node_list = [];

        while (content.length > 0) {
            debugger;

            const o = new SplitScriptTag(content);

            debugger;
            // script.tag 解析
            let { left, nodeList } = o.findScriptTag(content);
            debugger;

            content = left || '';
            node_list = node_list.concat(nodeList);
        }
        //-----------------------
        return node_list;
    }
    //--------------------------------------------------------------------------
    // API
    // 只需找一個 <script>
    static split(content) {
        debugger;

        const o = new SplitScriptTag(content);
        const { left, nodeList } = o.findScriptTag();

        debugger;
        return {
            left: left,
            nodeList: nodeList,
        };
    }
    //--------------------------------------------------------------------------
    findScriptTag() {
        (() => {
            debugger;
            /*
             * 找 <script> 開頭
             */
            if (!this._findHead()) {
                this.result.nodeList.push(this.content);
                return;
            }
            debugger;
            /*
             * 找 </script> 結尾
             */
            if (!this._findFoot()) {
                this.result.nodeList.push(this.content);
                return;
            }

            if (IS_COMMAND.test(this.head)) {
                this.isCommand = true;
            }
            debugger;

            this._generateNode();
        })();

        return this.result;
    }

    //--------------------------------------------------------------------------
    /**
     * 找 <script> 開頭
     *
     * @returns {Boolean}
     */
    _findHead() {
        // debugger;

        let c_content = this.content;

        // 找 <script
        let reg_res = SCRIPT_START_REG.exec(c_content);

        if (reg_res == null) {
            // 沒找到 <script.. 頭
            return false;
        }
        // 找到 <script.. 頭
        let hasChecked = RegExp.leftContext;
        let match = RegExp.lastMatch;
        let left = RegExp.rightContext;

        if (hasChecked.length) {
            // <script> 之前的內文
            this.prev = hasChecked;
        }

        this.head = match;
        //------------------
        // 找 <script> 頭的尾
        let find = null;

        // debugger;
        let reg = RegExp(SCRIPT_HEAD_END_REG.source, 'g');

        while ((reg_res = reg.exec(left))) {
            // 目的略過 tag_content 中的 <%= %>, <%- %>, <% %>
            if ($tool.isset(reg_res[1])) {
                hasChecked = RegExp.leftContext;
                match = RegExp.lastMatch;
                left = RegExp.rightContext;

                find = hasChecked + match;
                break;
            }
        }
        // debugger;

        if (find == null) {
            // <script> 頭的尾沒找到
            return false;
        }

        this.head += find;
        this.left = left;

        return true;
    }
    //--------------------------------------------------------------------------
    /**
     * 找 </script> 結尾
     *
     * @returns {Boolean}
     */
    _findFoot() {
        // debugger;

        let reg_res = SCRIPT_END_REG.exec(this.left);
        if (reg_res == null) {
            return false;
        }
        let hasChecked = RegExp.leftContext;
        let match = RegExp.lastMatch;
        let left = RegExp.rightContext;

        this.body = hasChecked;
        this.foot = match;
        this.result.left = left;

        return true;
    }
    //--------------------------------------------------------------------------
    _generateNode() {
        debugger;

        // 組合 this.head, this.body, this.foot
        // 成為節點
        const nodeList = this.result.nodeList;

        if (this.prev.length > 0) {
            nodeList.push(this.prev);
        }

        if (this.isCommand) {
            // 是命令標籤

            let $class = NODECLASS_MAP['command'];
            let node = new $class(this.body, 'script');
            nodeList.push(node);
        } else {
            // 拆分 <script> 內的命令標籤
            // 把 this.head 變為一般節點
            // 把 this.foot 變為一般節點

            nodeList.push(this.head);

            // 把責任交給另一模組
            let nodes = $SplitCommand.splitAll(this.body);

            nodes.forEach((v) => {
                debugger;

                let node;
                if(typeof(v) === "string"){
                    let $class = NODECLASS_MAP['script'];
                    node = new $class(v);
                }else{
                    node = v;
                }

                nodeList.push(node);
            });

            nodeList.push(this.foot);
        }
    }
}
module.exports = SplitScriptTag;
GModules.set('splitScriptTag', SplitScriptTag);
