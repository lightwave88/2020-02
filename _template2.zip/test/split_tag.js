const GModules = require('./gmodules.js');

if (!GModules.has('splitScriptTag')) {
    require('./splitScriptTag.js');
}
const $SplitScriptTag = GModules.get('splitScriptTag');
//-------------
if (!GModules.has('splitCommand')) {
    require('./splitCommand.js');
}
const $SplitCommand = GModules.get('splitCommand');
//-------------
if (!GModules.has('tool')) {
    require('./tool.js');
}
const $tool = GModules.get('tool');
//-------------
if (!GModules.has('normalNode_class')) {
    require('./node_1.js');
}
let { nodeclass_map } = GModules.get('normalNode_class');
const NODECLASS_MAP = nodeclass_map;
//-------------
/**
 * 給與內文
 * 然後分離出 command
 * 並且形成 nodeList
 */
class Splite_tag {

    constructor(content) {
        this.content = content;
        this.nodeList = [];
    }
    //--------------------------------------------------------------------------
    static main(content) {
        const o = new Splite_tag(content);
        debugger;

        let nodeList = o.splitTag();

        debugger;

        nodeList.forEach((v, i)=>{
            if(typeof(v) === 'string'){
                let $class = NODECLASS_MAP['normal'];
                nodeList[i] = new $class(v);
            }
        });

        return nodeList;
    }
    //--------------------------------------------------------------------------
    splitTag() {
        debugger;
        // 先把<script>分割出來
        this._splitScriptTag();		
		
        debugger;

        this._splitCommandTag();

        return this.nodeList;
    }
    //--------------------------------------------------------------------------
    // 先分離出<script>
    _splitScriptTag() {
        debugger;

        // script.tag 解析
        let nodeList = $SplitScriptTag.splitAll(this.content);

        debugger;
        this.nodeList = this.nodeList.concat(nodeList);
    }
    //--------------------------------------------------------------------------
    _splitCommandTag() {
        let $nodeList = [];

        let prev;
        this.nodeList.forEach((node, i) => {
            debugger;
            if (typeof node === 'string') {

                if (node.length) {
                    if (prev == null) {
                        prev = node;
                    } else {
                        prev += node;
                    }
                }

                if (!$tool.isset(this.nodeList[i + 1])) {
                    // 到底了
                    let nodes = this._splitCommand(prev);
                    prev = null;
                    debugger;
                    $nodeList = $nodeList.concat(nodes);
                }
            } else {
                if (prev != null) {
                    let nodes = this._splitCommand(prev);
                    prev = null;
                    debugger;
                    $nodeList = $nodeList.concat(nodes);
                }
                $nodeList.push(node);
            }
        });
        //-----------------------
		
		console.dir($nodeList);

        this.nodeList = $nodeList.map((v) => {
            if (typeof (v) === 'string') {
                return this._instanceNormalNode(v);
            }
            return v;
        });
    }
    //--------------------------------------------------------------------------
    _splitCommand(content) {
        debugger;
        let nodeList = $SplitCommand.splitAll(content);
        debugger;
        return nodeList;
    }
    //--------------------------------------------------------------------------    
    _instanceNormalNode(content) {
        let $class = NODECLASS_MAP['normal'];
        return new $class(content);
    }
}


class Test {
    //--------------------------------------------------------------------------

    step_1() {
        let nodeList = [];

        let content = this.content;

        while (content.length > 0) {
            // debugger;

            let res = this._findCommandTag(content);

            let nodes = res.nodeList;
            content = res.left || '';

            nodeList = nodeList.concat(nodes);
        }
        //-----------------------
        return nodeList;
    }
    //--------------------------------------------------------------------------
    // 標籤頭的規則
    _get_tagReg() {
        let reg_1 = /<(script)(?=>|\s)/;
        let headTag = /(<%[-=]?)/;

        let mainReg = RegExp(`${reg_1.source}|${headTag.source}`);

        return mainReg;
    }
    //--------------------------------------------------------------------------
    // 找到 target 一次一個
    // res要返回 nodeList
    // 返回 remain
    // rValue: 回傳值
    _findCommandTag(content) {
        debugger;

        const rValue = {
            nodeList: null,
            left: '',
        };

        let res;
        let hasChecked = '';

        // 先找尋可能的 taghead
        while ((res = this.reg_1.exec(content)) != null) {
            debugger;

            hasChecked += RegExp.leftContext;

            let tagHead = RegExp.lastMatch;
            let remain = RegExp.rightContext;

            //-----------------------
            let tagName = res[2] || res[3] || null;

            if (tagName) {
                // (%, <% 標籤

                if (G.commandTagName == null) {
                    G.commandTagName = tagName.substr(0, 2);
                    G.reg_1 = _getReg_1();
                }
            } else {
                // <script> 標籤
                tagName = res[1] || null;
            }
            //-----------------------
            let methodClass = CheckTag_methodList[tagName];
            if (methodClass == null) {
                throw new Error(`(${tagName}) no support method`);
            }

            // 找標籤所屬的尾
            let method = new methodClass($root, tagHead, remain);
            let _res = method.check();

            // debugger;
            let find = _res.find;

            if (find) {
                remain = _res.remain;
                let nodes = _res.nodes;

                if (!Array.isArray(nodes)) {
                    throw new TypeError('tagMethod must be return []');
                }

                if (hasChecked) {
                    nodes.unshift(hasChecked);
                }

                rValue.find = true;
                rValue.nodeList = _getNodeList(nodes);
                rValue.remain = remain;
                return rValue;
            }
            //------------------
            hasChecked += _res.hasChecked;
            content = _res.remain;
        } // while end
        //-----------------------
        // 都沒找到
        debugger;

        rValue.hasChecked = hasChecked + content;
        return rValue;
    }
    //--------------------------------------------------------------------------
    step_2() {

    }
    //--------------------------------------------------------------------------
}

module.exports = Splite_tag;
GModules.set('splite_tag', Splite_tag);
