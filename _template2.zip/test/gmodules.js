const GModules = new Map();

module.exports = GModules;
