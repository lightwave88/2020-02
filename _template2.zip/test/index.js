const $util = require('util');
const GModules = require('./gmodules.js');
const $Splite_tag = require('./split_tag.js');

const $Out = require('./outObject.js');
const $Page = require('./pageObject');

module.exports = function (content) {
    const o = new Analyze();
    return o.analyzeCotent(content);
};

class Analyze {

    constructor() {

    }

    analyzeCotent(content) {
        debugger;

        let nodeList = $Splite_tag.main(content);

        let command = '';

        nodeList.forEach((node) => {
            command += node.printCommand();
        });

        let fun_content = `${command}`;
        
        new Function('base_url', 'Page', 'Out', fun_content);

        console.log($util.inspect(command));
    }
}


