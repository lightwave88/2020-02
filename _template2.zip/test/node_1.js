const GModules = require('./gmodules.js');

const $export = {
    node_abs: null,
    nodeclass_map: null,
};
GModules.set('normalNode_class', $export);

////////////////////////////////////////////////////////////////////////////////
//
// 節點
//
////////////////////////////////////////////////////////////////////////////////
const REG_1 = /([^\\]?)`/g

/**
 * 抽象類
 */
class Node_ABS {
    constructor() {
    }
    //----------------------------
    // 最主要的
    printCommand() {
        throw new Error('need override printCommand');
    }
    //----------------------------
    // 脫逸 `
    _checkHtml(content) {
        content = content.replace(REG_1, function (m, g1) {
            let res = g1 + '\\' + '`';
            return res;
        });

        return content;
    }
    //----------------------------
}
$export['node_abs'] = Node_ABS;
////////////////////////////////////////////////////////////////////////////////
//
// 節點
//
////////////////////////////////////////////////////////////////////////////////
const NODECLASS_MAP = {};
$export['nodeclass_map'] = NODECLASS_MAP;

// 沒有命令的節點
(function () {
    class NormalNode extends Node_ABS {
        constructor(content) {
            super();
            this.html = content;
        }
        //----------------------------
        printCommand() {
            this.html = this._checkHtml(this.html);
            let content = `Out.print(\`${this.html}\`);\n`;
            return content;
        }
        //----------------------------
        toString() {
            return `NormalNode(${this.html})`;
        }
    }
    NODECLASS_MAP['normal'] = NormalNode;
})();
//==============================================================================
(function () {

    /**
     * 拆分的 script 內容
     */
    class ScriptNode extends Node_ABS {

        // isTag:是否是標籤內容
        constructor(content) {
            super();
            this.html = content;
        }
        //----------------------------
        printCommand() {
            let content;

            // 不能經過 String.template 轉換
            let html = JSON.stringify(this.html);
            content = `Out.print(${html});\n`;

            return content;
        }
        //----------------------------

    }
    NODECLASS_MAP['script'] = ScriptNode;
})();

//==============================================================================


(function () {
    /*
     * 基本命令標籤
     */
    class CommandNode extends Node_ABS {

        // include: {}: include() 的位置上
        constructor(content, tagName) {
            super();

            this.content = content || '';

            this.tagName = tagName;

            this.script = '';

            this._buildScript();
        }
        //----------------------------
        printCommand() {
            return this.script;
        }
        //----------------------------
        _buildScript() {
            let textContent;
            let script;
            switch (this.tagName) {
                case 'script':
                case '<%':
                    script = this.content;
                    break;
                case '<%=':
                    textContent = this.content.trim();
                    textContent = textContent.replace(/;$/, '');
                    if (textContent) {
                        script = `Out.print(${textContent});\n`;
                    }
                    break;
                case '<%-':
                    textContent = this.content.trim();
                    textContent = textContent.replace(/;$/, '');
                    if (textContent) {
                        script = `Out.escape(${this.content});\n`;
                    }
                    break;
            }

            if (script == null) {
                throw new Error(`commandName (${this.tagName}) no exists`);
            }
            this.script = script;
        }
        //----------------------------
        toString() {
            return `CommandNode(${this.content})`;
        }
        //----------------------------
    }

    NODECLASS_MAP['command'] = CommandNode;
})();

//==============================================================================

module.exports = $export;
