const GModules = require('./gmodules.js');

if (!GModules.has('tool')) {
    require('./tool.js');
}
const $tool = GModules.get('tool');
//-------------
if (!GModules.has('normalNode_class')) {
    require('./node_1.js');
}
let { nodeclass_map } = GModules.get('normalNode_class');
const NODECLASS_MAP = nodeclass_map;
//-------------
if (!GModules.has('actionNode_class')) {
    require('./node_2.js');
}
const ACTIONNODECLASS_MAP = GModules.get('actionNode_class');
//-------------

const ACTION_END_REG = /(?:<%=[\s\S]*?%>)|(?:<%-[\s\S]*?%>)|((\/?)>)/;
const TAG_HEAD_REG = /(?:(<%[-=]?)|<js:(?=\w))/;
const COMMAND_TAG_END_REG = /[\\]?%>/;

const TAG_PARAM_REG = /([^=\s]+)\s*=\s*("|')(?:\2|([\s\S]*?[^\\])\2)/;

const REG_1 = /^js:\w/;

const REG_2 = /<%[-=]([\s\S]*?)%>/;

// 正常 heml_tag 的規則
// 會捕捉 tag_name
const REGULER_HTMLTAG_REG =
    /<([a-z][\s\S]{0,}?)(?:\s[\s\S]{0,}?|)([\/]?)>|<\/([a-z][\s\S]{0,}?)>/;

const ACTION_NAME = 'js';
/**
 * 把命令分離出來
 * <% %>, <%- %>, <%= %>, <js:action...>
 */
class SplitCommand {
    constructor(content) {
        this.content = content;

        // 前面無關的文字
        this.prev = '';

        // 剩下未檢查的文字
        this.left = '';

        // 命令種類
        this.command;

        // 動作種類
        this.action;

        // 標籤內文
        this.body = '';
        //------------------
        // <jsp:action> 用
        this.params = {};

        // <jsp:action> 用
        this.tag_params = {};
        //------------------
        this.result = {
            nodeList: [],
            left: '',
        };
    }
    //--------------------------------------------------------------------------
    // API
    static splitAll(content) {
        debugger;

        let node_list = [];

        while (content.length > 0) {
            debugger;

            const o = new SplitCommand(content);

            debugger;
            // script.tag 解析
            let { left, nodeList } = o.split(content);
            debugger;

            content = left || '';
            node_list = node_list.concat(nodeList);
        }
        //-----------------------
        return node_list;
    }
    //--------------------------------------------------------------------------
    // API
    static split(content) {
        debugger

        const o = new SplitCommand(content);
        const { left, nodeList } = o.split();
        return {
            left: left,
            nodeList: nodeList,
        };
    }
    //--------------------------------------------------------------------------
    split() {

        (() => {
            debugger;

            let content = this.content;

            // 找合乎的標籤頭
            const reg_1 = RegExp(TAG_HEAD_REG.source);
            let reg_res = reg_1.exec(content);

            let hasChecked;
            let match;
            let left;

            if (reg_res == null) {
                // 連頭都沒找到
                this.result.nodeList.push(this.content);
                return;
            } else {
                hasChecked = RegExp.leftContext;
                match = RegExp.lastMatch;
                left = RegExp.rightContext;

                this.prev = hasChecked;
                this.left = left;
            }
            //------------------
            let findEnd;

            if ($tool.isset(reg_res[1])) {
                // <% %>,<%= %>,<%- %>
                this.command = reg_res[1];
                findEnd = this._findCommandEnd();
            } else {
                // <js:command >
                findEnd = this._findAction();
            }
            debugger;
            if (!findEnd) {
                this.result.nodeList.push(this.content);
                return;
            }

            this._generateNode();
        })();

        return this.result;
    }
    //--------------------------------------------------------------------------
    _findAction() {
        debugger;

        // <jsp:action....>
        let reg = RegExp(ACTION_END_REG.source, 'g');
        let reg_res;

        let hasChecked;
        // let match;
        let left = this.left;
        let is_singleTag;

        while ((reg_res = reg.exec(left)) != null) {
            debugger;

            // 此舉是為了能跳過 <%= %>, <%- %>
            // 找到 <jsp:action...> 的 end
            if ($tool.isset(reg_res[1])) {
                // find
                hasChecked = RegExp.leftContext;
                // match = RegExp.lastMatch;
                left = RegExp.rightContext;

                is_singleTag = ($tool.empty(reg_res[2])) ? false : true;
                this.left = left;
                break;
            }
        }

        if (is_singleTag == null) {
            return false;
        }
        //-----------------------
        // 找到標籤
        // 從 tag 內容取出 tag 屬性
        let tag_content = hasChecked;
        let { params, action } = this._checkActionTagContent(tag_content);

        this.tag_params = params;
        this.action = action;

        if (!is_singleTag) {
            // 若不是單一標籤，還要確認結尾
            // 並收集可能有的 params
            this._findActionEnd();
        }

        return true;
    }
    //--------------------------------------------------------------------------
    // <jsp:action...>已經找到
    // 找尋可能的 action 的 end
    _findActionEnd() {
        debugger;

        // 找尋連續的<jsp:action...></jsp:action>
        let res;

        let left = this.left;

        let is_end_tag = false;

        let find_param;

        // 抓到任何的 html(包括命令) 標籤
        while ((res = REGULER_HTMLTAG_REG.exec(left)) != null) {

            // 有找到任何的標籤
            let match = RegExp.lastMatch;
            let _left = RegExp.rightContext;

            let tagName;

            // 辨識標籤
            if (res[1] != null) {
                // 找到開始標籤
                tagName = res[1];
            } else if (res[3] != null) {
                // 找到結束標籤
                // end tag
                is_end_tag = true;
                tagName = res[3];
            }
            //------------------
            if (REG_1.test(tagName)) {
                // 有找到 action 標籤
                if (is_end_tag) {
                    // 有找到 action 結束標籤
                    // 結束
                    this.result.left = _left;
                    return;
                } else {
                    // 是 <js:param> 標籤
                    if (find_param == null) {
                        find_param = true;
                    }
                    // 找到參數標籤 <jsp:param ....>
                    let tag_content = match.replace(/^</, '').replace(/\/?>$/, '');
                    this._getParams(tag_content);
                }
            } else {
                // 找到標籤但不是 action 標籤
                // action 標籤沒相連，結束尋找過程
                break;
            }
        }
        //----------------------------
        // 文本都沒發現 tag
        if (find_param) {
            throw new Error('</js:action> no exists');
        }
        this.result.left = left;

    }
    //--------------------------------------------------------------------------
    // 找 <% %>, <%- %>, <%= %> 的結尾
    _findCommandEnd() {

        if (!COMMAND_TAG_END_REG.test(this.left)) {
            return false;
        }
        let hasChecked = RegExp.leftContext;
        // let match = RegExp.lastMatch;
        let left = RegExp.rightContext;

        this.result.left = left;
        this.body = hasChecked;

        return true;
    }
    //--------------------------------------------------------------------------
    // 取得 action 標籤的 action 與 params
    _checkActionTagContent(tagcontent) {
        debugger;
        let r_value = {
            action: '',
            params: {}
        };

        const $params = r_value.params;

        tagcontent = tagcontent.trim();

        if (/\s{1,}/.test(tagcontent)) {
            r_value.action = RegExp.leftContext;
            tagcontent = RegExp.rightContext;
        } else {
            // 沒有 params
            r_value.action = tagcontent;
            return r_value;
        }
        //------------------
        let reg = RegExp(TAG_PARAM_REG.source, 'g');
        let res;

        debugger;
        while ((res = reg.exec(tagcontent))) {
            debugger;

            let key = res[1];
            let content = res[3] || '';

            if (!key) {
                throw new Error(`(${r_value.action}) param key has problem`);
            }
            $params[key] = content;
        }

        debugger;

        // 整理 param
        for (const key in $params) {
            debugger;
            if ($params.hasOwnProperty(key)) {
                let content = $params[key];
                let left = content;

                let fix = '';
                let res;
                while ((res = REG_2.exec(left)) != null) {
                    let checked = RegExp.leftContext;
                    let match = res[1].trim();
                    left = RegExp.rightContext;
                    fix += JSON.stringify(checked) + `+(${match})+`;
                }

                if (fix.length > 0) {
                    fix += JSON.stringify(left);
                    $params[key] = `(${fix})`;
                }
            }
        }

        return r_value;
    }
    //--------------------------------------------------------------------------
    // <jsp:param>
    _getParams(tagContent) {
        let { action, params } = this._checkActionTagContent(tagContent);

        if (!/^param$/.test(action)) {
            throw new Error(`<jsp:param> tagName(${action}) error`);
        }
        let key = params.name;
        let value = params.value;

        this.params[key] = value;
    }

    //--------------------------------------------------------------------------
    _generateNode() {
        debugger;

        const nodeList = this.result.nodeList;

        if (!$tool.empty(this.prev)) {
            nodeList.push(this.prev);
        }

        let node;
        let $class;
        if (this.command != null) {
            $class = NODECLASS_MAP['command'];
            node = new $class(this.body, this.command);
        } else if (this.action != null) {
            $class = ACTIONNODECLASS_MAP[this.action];

            if($class == null){
                throw new Error(`cant find (${this.action}) class`);
            }

            node = new $class(this.tag_params, this.params);
        } else {
            throw new Error('...');
        }
        nodeList.push(node);
    }
}

module.exports = SplitCommand;
GModules.set('splitCommand', SplitCommand);
