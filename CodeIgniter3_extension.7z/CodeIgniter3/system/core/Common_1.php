<?php

namespace ci\system\fun;

use Exception;

////////////////////////////////////////////////////////////////////////////////
//
// 不想對外的函式，系統內部的函式
// 放這邊
//
////////////////////////////////////////////////////////////////////////////////
function coreConfig($key = null) {
    static $core_settings;

    if (is_null($key)) {
        return $core_settings;
    }
    //------------------

    $keyList = explode('.', $key);

    $dirList = array(
        (BASEPATH . 'config/'),
        (APPPATH . 'system/config/')
    );

    if (!isset($core_settings)) {
        $fileName = 'system_config.php';

        foreach ($dirList as $dir) {
            $file = $dir . $fileName;
            require($file);

            if (!isset($core_settings)) {
                $core_settings = &$config;
            }
        }
    }

    $setting = $core_settings;

    foreach ($keyList as $k) {
        if (!isset($setting[$k])) {
            $setting = null;
            break;
        }
        $setting = $setting[$k];
    }

    return $setting;
}

//------------------------------------------------------------------------------
/**
 * 為 class 取得一個索引名稱
 *
 * @param type $class
 * @param type $prefix: [true:用預設的 prefix|string:自訂的prefix]
 * @return type
 */
function key_checkClassName($class, $prefix = FALSE) {
    $class = '\\' . ltrim($class, '\\');
    $indexName = $class;

    if (is_bool($prefix)) {
        if ($prefix) {
            $indexName = $indexName . '::class';
        }
    } else {
        $indexName = $prefix . $indexName;
    }

    return $indexName;
}

//------------------------------------------------------------------------------
/**
 * 把 moduleName 統一規格化
 *
 * @param type $moduleName
 * @return type
 */
function key_checkModuleName($moduleName) {

    $moduleName = trim($moduleName, '\\/');
    $moduleName = preg_replace('/\\//', '\\', $moduleName);

    $last_slash = strrpos($moduleName, '\\');

    $subdir = '';
    if (isset($last_slash)) {
        $subdir = substr($moduleName, 0, ++$last_slash);
        $moduleName = substr($moduleName, $last_slash);
    }

    $moduleName = ucfirst($moduleName);

    return array($subdir, $moduleName);
}

//------------------------------------------------------------------------------
/**
 * 把 moduleName 正規化為變數名稱
 *
 * @param type $module
 * @return type
 */
function key_getModuleVarName($module) {
    $module = strtolower($module);
    $module = trim($module, '\\/');

    $varmap = coreConfig('varmap');
    if (isset($varmap[$module])) {
        $module = $varmap[$module];
    }
    $separator = preg_quote('\\');
    $preg = sprintf('/(?:%s|\\/)/', $separator);

    $module = preg_replace($preg, '_', $module);
    return $module;
}

//------------------------------------------------------------------------------
function callController($parent = null, array $options = array()) {

    $dir = '';
    $class = NULL;
    $method = coreConfig('controller.default_method');
    $param = array();
    //----------------------------

    if (!empty($options['dir'])) {
        $dir = $options['dir'];
        $dir = trim($dir, '\\/');
        $dir = $dir . '\\';
    }

    if (!empty($options['method'])) {
        $method = $options['method'];
    }

    if (empty($options['controller'])) {
        throw new \Exception("no assign controller");
    } else {
        $class = $options['controller'];
    }

    if (isset($options['param']) && is_array($options['param'])) {
        $param = $options['param'];
    }
    //------------------
    // 取得 conroller.class 

    $abs_class = SYS_ROOT_NAMESPACE . 'CI_Controller';

    if (!class_exists($abs_class)) {
        $file = BASEPATH . 'core1/Container/Controller.php';
        \include_class($file, $abs_class, TRUE);
    }

    $file = APPPATH . 'controllers/' . $dir . $class . '.php';
    $class = ucfirst($class);
    $className = \config('controller_namespace') . $dir . $class;

    if (!file_exists($file)) {
        throw new \Exception("no controller({$className}) file");
    }

    if (!class_exists($className)) {
        \include_class($file, $className, TRUE);
    }
    //----------------------------
    // 實例化 controller
    // 取出 interceptor setting
    // 執行 interceptor
    // 檢查是否有 cache 的存在
    // 執行 controller->method()
    // 返回 controller->method() 結果
    // 執行 interceptor
    //----------------------------
    // 實例化 controller
    $controller = new $className($parent);

    // 關閉 controller 設定 filter 的能力
    $controller->_ci_inited = true;
    //-------------------
    // 記錄使用中的 container
    \get_container($controller);

    // 執行 controller
    $result = call_user_func_array(array(&$controller, $method), $param);

    \get_container($parent);

    //-------------------

    return array(
        'controller' => $controller,
        'method' => $method,
        'result' => $result
    );
}

//------------------------------------------------------------------------------
/**
 * 根據需要的 result
 * 返回 className
 */
function get_actionResult($resultName = null, $limits = null) {
    // 記錄 class 的單例
    static $loaded = array();

    $args = func_get_args();

    if (count($args) < 1) {
        return $loaded;
    }
    //------------------
    // 檢查 result 是否在允許的列表裡 
    if(is_array($limits)){
        foreach ($limits as $limit) {
            $judge = strcasecmp($resultName, $limit);
            if ($judge === 0) {
                goto anchor_1;
            }
        }
        throw new \Exception("action result({$resultName}) not allow");
        anchor_1:
    }

    $moduleName = ucfirst($resultName);

    if (isset($loaded[$moduleName])) {
        return $loaded[$moduleName];
    }
    //------------------
    // 先引入 abs
    $absClass = SYS_ROOT_NAMESPACE . 'result\\CI_ActionResult';

    if (!class_exists($absClass)) {
        $file = BASEPATH . 'core1/Action_result/Action_result.php';
        \include_class($file, $absClass, true);
    }
    //------------------   

    $fileName = $moduleName . '_result.php';

    $pathList = coreConfig('action_result.result_file_dir');

    foreach ($pathList as $dir) {
        $file = $dir . $fileName;
        if (file_exists($file)) {
            require_once($file);
        }
    }
    throw new \Exception("action_result(${$moduleName}) file no exists");

    $namespace = coreConfig('action_result.result_class_namespace');

    $class = $namespace . 'CI_' . $fileName;
    if (!class_exists($class)) {
        throw new \Exception("action_result(${$moduleName} class({$class}) no exists");
    }

    $this->instanced[$$moduleName] = $class;

    return $class;
}

//------------------------------------------------------------------------------
/**
 * 取得要的 view-engine
 * 
 * @staticvar array $instanced
 * @param type $engineName
 * @param array $init
 */
function get_viewEngine($context, $engineName = null, array $init = array()) {

    if (is_null($engineName)) {
        // 若沒指定 view engine 採用預設
        $engineName = coreConfig('view_engine.default_engine');
    }
    //-----------------------
    $engineName = strtolower($engineName);

    // load abs class
    $abs_class = SYS_ROOT_NAMESPACE . 'result\\Veiw_result';
    if (!class_exists($abs_class)) {
        $file = BASEPATH . '/core1\Action_result/action_results/View_result.php';

        //console()->log('%s => %s', $file, $abs_class);

        \include_class($file, $abs_class, true);
    }

    // load module
    $engine_dir_list = coreConfig('view_engine.module_dir');

    $file_exists = false;
    foreach ($engine_dir_list as $dir) {
        $file = $dir . $engineName . '/install.php';
        if (file_exists($file)) {
            require_once($file);
            $file_exists = true;
            break;
        }
    }

    if (!$file_exists) {
        throw new \Exception(sprintf('view_engine(%s) install file(%s) no exists', $engineName, json_encode($engine_dir_list)));
    }
    //-----------------------

    $fun = SYS_ROOT_NAMESPACE . 'view\\' . $engineName . '\\install';

    if (!function_exists($fun)) {
        throw new \Exception(sprintf('view_engine(%s) install function no exists', $engineName));
    }

    /**
     * 暫時替代
     * 應該取自 app/view_engine/{$engineName}/config.php
     */
    $config = array();

    $ob_level = $context->_ci_ob_level;
    if (!isset($ob_level)) {
        $ob_level = ob_get_level();
        $context->_ci_ob_level = $ob_level;
    }

    $args = array(
        'module_name' => $engineName,
        'config' => $config,
        'context' => $context,
        'ob_level' => $ob_level
    );

    $args = array_unshift($init, $args);

    $instance = call_user_func_array($fun, $init);

    return $instance;
}

//------------------------------------------------------------------------------
/**
 * load 新的核心模組 的方法
 * 
 * @param type $className
 * @param type $path
 * @param type $param
 * @param type $single
 * @return type
 */
function &load_class($className, $path, $param = array(), $single = TRUE) {
    $lib = lib();
    $lib_class = get_class($lib);

    $instance = &$lib_class::load_system_class($className, $path, $param, $single);
    return $instance;
}

//------------------------------------------------------------------------------
function container_load_core($target, $m_name, $instance) {
    $core_loadList = coreConfig('core_loadList');



    foreach ($core_loadList as $moduleName) {
        // 要載入列表

        $judge = strcasecmp($m_name, $moduleName);

        // console()->log('match(%s) res(%b)', $moduleName, $judge);

        if ($judge == 0) {
            // 載入列表有指定要載入的 core
            $varName = key_getModuleVarName($moduleName);

            if (isset($target->$varName) && $target->$varName === $instance) {
                break;
            }
            //-----------------------
            $moduleName = strtolower($moduleName);
            $target->$varName = &$instance;
            $target->_ci_classes[$varName] = $moduleName;

            $className = get_class($instance);
            $className = key_checkClassName($className, true);
            $target->_ci_classes[$className] = $moduleName;
            break;
        }
    }
}
//------------------------------------------------------------------------------
function container_load_cores($target) {
    $core_loadList = coreConfig('core_loadList');

    foreach ($core_loadList as $moduleName) {

        $varName = key_getModuleVarName($moduleName);

        $core = &\load_class($moduleName, 'core');

        if (isset($target->$varName) && $target->$varName === $core) {
            continue;
        }
        //----------------

        $target->$varName = &$core;

        $_moduleName = strtolower($moduleName);
        $target->_ci_classes[$varName] = $_moduleName;

        $className = get_class($core);
        $className = key_checkClassName($className, true);
        $target->_ci_classes[$className] = $_moduleName;
    }
}
