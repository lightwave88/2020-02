<?php

namespace ci\system\view\ci3;

use ci\system\result\Veiw_result;
use Exception;

/**
 * 要操作的實體
 */
class View implements Veiw_result {

    const RENDER_ACTION_CLASS = '\\Render_action';
    const RENDER_ACTION__FILE = '/Render_action.php';

    /**
     * view 的 this
     * 上下文
     * 
     * @var type 
     */
    protected $_ci_context;

    /**
     * 使用者設定的 config
     * 
     * @var type 
     */
    protected $_ci_config;

    /**
     * 模組名稱
     * 
     * @var type 
     */
    protected $_ci_module_name;

    /**
     * 處理 view 套嵌問題 
     * 
     * @var type 
     */
    protected $_ci_container_ob_level;
    //-----------------------

    /**
     * view 內的變數
     * 
     * @var type 
     */
    protected $_ci_cached_vars = array();

    /**
     * layout 的路径
     * 
     * @var type 
     */
    protected $_ci_layout_file;

    /**
     * 記錄有多少次 view 的套嵌
     * 
     * @var type 
     */
    protected $_ci_render_stack = array();

    //--------------------------------------------------------------------------
    public function __construct(array $options = array()) {

        $errorList = array();

        $this->_ci_context = $options['context'];
        $this->_ci_config = $options['config'];
        $this->_ci_module_name = $options['module_name'];
        $this->_ci_container_ob_level = $options['ob_level'];
        //------------------

        if (!is_object($this->_ci_context)) {
            $errorList[] = 'view engine no set context';
        }

        if (!is_array($this->_ci_config)) {
            $errorList[] = 'view engine config type error';
        }

        if (empty($this->_ci_module_name)) {
            $errorList[] = 'no set view engine name';
        }

        if (!is_int($this->_ci_container_ob_level)) {
            $errorList[] = 'no set view engine ob_level';
        }

        if (count($errorList) > 0) {
            $msg = join('|', $errorList);
            throw new \Exception($msg);
        }
    }

    //--------------------------------------------------------------------------

    /**
     * load view 檔案
     * 
     * @param type $file
     * @param array $data
     * @return $this
     * @throws \Exception
     */
    public function load($file, array $data = array()) {

        if (!is_array($data)) {
            $data = array();
        }
        //------------------
        $id = 'id_' . count($this->_ci_render_stack);

        $options = array(
            'id' => $id,
            'data' => $data,
            'file' => $file,
            'layout' => $this->_ci_layout_file
        );

        $render_action = &$this->_initRenderAction($options);

        // 記錄 render 的堆疊
        $this->_ci_render_stack[$id] = $render_action;

        $content = $this->_ci_render_action->render();

        $this->_ci_reset();

        return $content;
    }

    //--------------------------------------------------------------------------

    /**
     * 若 view 使用 layouy
     * 
     * @param type $file
     * @param array $data
     * @throws \Exception
     */
    public function layout($file) {
        if (count($this->_ci_render_stack) > 0) {
            // 不能在 view 的套嵌時指定
            throw new \Exception("cant assign layout in view nest");
        }
        $this->_ci_layout_file = $file;
    }

    //--------------------------------------------------------------------------
    public function vars($vars, $val = '') {
        
    }

    //--------------------------------------------------------------------------
    public function clear_vars() {
        
    }

    //--------------------------------------------------------------------------
    public function get_var($key) {
        
    }

    //--------------------------------------------------------------------------
    public function get_vars() {
        
    }

    //--------------------------------------------------------------------------

    /**
     * override
     */
    public function ExecuteResult() {
        
    }

    //--------------------------------------------------------------------------

    /**
     * override
     */
    public function getOutput() {
        // console()->log('getOutput()');
        $content = $this->_ci_content;
        $this->_ci_content = null;
        return $content;
    }

    //--------------------------------------------------------------------------
    protected function &_initRenderAction($options) {

        $class = __NAMESPACE__ . self::RENDER_ACTION_CLASS;
        $file = __DIR__ . self::RENDER_ACTION__FILE;

        \include_class($file, $class, true);

        $instance = new $class($this, $options);

        return $instance;
    }

    //--------------------------------------------------------------------------
    protected function _ci_reset() {
        $this->_ci_layout_file = null;
    }

}
