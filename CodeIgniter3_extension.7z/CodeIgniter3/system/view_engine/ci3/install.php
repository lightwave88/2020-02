<?php

namespace ci\system\view\ci3;

/**
 * 模組對外的接口
 */
function &install() {
     console()->log('ci3 install');
    $args = func_get_args();

    $class = SYS_ROOT_NAMESPACE . 'view\\ci3\\View';
    if (!class_exists($class)) {
        $file = __DIR__ . '/View.php';
        \include_class($file, $class, true);
    }

    // console()->dump($args);

    $install = &\instance_class($class, $args);

    return $install;
}
