<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace ci\system\view\ci3;

/**
 * 只負責一次的 render 任務
 *
 * @author xman
 */
class Render_action {

    protected $view;

    /**
     * 記錄每個 page 的資訊
     * @var type 
     */
    protected $pages = array();

    /**
     * layout 的路径
     * 
     * @var type 
     */
    protected $layout_file = '';

    /**
     * 记录 layout 会用到的 section
     * 
     * @var type 
     */
    protected $sectionContents = array();

    /**
     * view file
     * 
     * @var type 
     */
    protected $view_file = '';

    /**
     * data
     * 
     * @var type 
     */
    protected $data = array();

    /**
     * 給與每個 page 可辨認的 id
     * 
     * @var type 
     */
    protected $page_id = 0;
    protected $self_id;

    //--------------------------------------------------------------------------
    public function __construct($view, $options) {
        $this->view = $view;

        $this->view_file = $options['file'];
        $this->layout_file = $options['layout'];
        $this->self_id = $options['id'];

        if (is_array($options['data'])) {
            $this->data = array_combine($this->data, $options['data']);
        }

        $this->view_file = $this->_checkViewFile($this->view_file);

        if (!empty($this->layout_file)) {
            $this->layout_file = $this->_checkLayoutFile($this->layout_file);
        }
    }

    //--------------------------------------------------------------------------
    public function render() {

        $vars = array_merge($this->view->_ci_cached_vars, $this->data);

        $file = $this->view_file;

        $options = array(
            'context' => $this->view->_ci_context,
            'vars' => $vars,
            'file' => $this->view_file,
            'ob_level' => $this->view->_ci_container_ob_level
        );

        $content = $this->_render($options);

        // 任務結束
        // 從任務堆疊中移除自己
        unset($this->view->_ci_render_stack[$this->self_id]);

        return $content;
    }

    //--------------------------------------------------------------------------
    protected function _render(array $options) {

        $file = $options['file'];

        $options['id'] = $this->page_id++;
        //-----------------------

        $class = SYS_ROOT_NAMESPACE . self::FACTORY_2_CLASS;
        $file = BASEPATH . self::FACTORY_2_FILE;

        if (!class_exists($class)) {
            \include_class($file, $class, true);
        }
        //------------------
        // view 進行 render
        $factory = new $class($this, $options);
        //------------------
        // view render 完
        if (isset($this->layout_file) || count($factory->_ci_pageData['sections']) > 0):
            // layout.child
            $id = $factory->_ci_pageData['id'];

            // 記錄 page 資料
            $this->pages[$id] = $factory->_ci_pageData;

            // 是否有 extend 的 parent
            if (is_null($factory->_ci_pageData['extend'])) {
                // 截取 layout 子頁面的資料已結束
                // 已經到達最頂層
                return;
            } else {
                // 截取 parent 的頁面資料
                $extend_file = $factory->_ci_pageData['extend'];
                $options['file'] = $this->_checkViewFile($extend_file);

                /*
                 * 分析父頁面
                 * 會不斷遞迴往上分析直到最頂 
                 */
                $this->_render($options);

                //------------------
                if ($id > 0) {
                    return;
                } else {
                    // 最底層的頁面
                    // 解析 layout
                    // end
                    if (empty($this->layout_file)) {
                        throw new \Exception("no set layout file");
                    }
                    $options['file'] = $this->layout_file;

                    // 整理 layout.sections 
                    $this->_checkLayoutSections();
                    return $this->_render($options);
                }
            }
        endif;
        // 一般 view
        $content = $factory->getResult();
        //-----------------------
        return $content;
    }

    //--------------------------------------------------------------------------
    protected function _checkLayoutSections() {
        while (($page = array_shift($this->pages)) && isset($page)):
            foreach ($page['sections'] as $key => $value) {
                if (isset($this->sectionContents[$key])) {
                    continue;
                }
                $this->sectionContents[$key] = $value;
            }
            unset($page);
        endwhile;
    }

    //--------------------------------------------------------------------------
    protected function _checkViewFile($file) {
        // 是否有副檔名
        $_ci_ext = pathinfo($file, PATHINFO_EXTENSION);
        $_ci_file = $file;
        if (empty($_ci_ext)) {
            $_ci_file = $file . '.php';
        }
        $view_file = VIEWPATH . $_ci_file;

        if (!file_exists($view_file)) {
            throw new \Exception("view({$view_file}) no exists");
        }
        return $view_file;
    }

    //--------------------------------------------------------------------------
    protected function _checkLayoutFile($file) {

        // layout 檔名的前綴
        $layout_file_prefix = config('layout_file_prefix');

        if (!empty($layout_file_prefix)) {
            $preg = sprintf('/^%s/i', $layout_file_prefix);
            if (!preg_match($preg, $file)) {
                $file = $layout_file_prefix . $file;
            }
        }

        // 是否有副檔名
        $_ci_ext = pathinfo($file, PATHINFO_EXTENSION);
        $_ci_file = $file;
        if (empty($_ci_ext)) {
            $_ci_file = $file . '.php';
        }

        $view_file = VIEWPATH . $_ci_file;

        if (!file_exists($view_file)) {
            throw new \Exception("view({$view_file}) no exists");
        }
        return $view_file;
    }

}
