<?php

use ci\system\database\ci3\CI_DB_driver;

if (!class_exists('CI_DB_driverCI_DB_driver')) {
    $file = __DIR__ . '/DB_driver.php';
    require_once($file);
}

abstract class CI_DB extends CI_DB_driver {

    protected $_db_expand_list = array();

    //--------------------------------------------------------------------------
    final public function _db_add_expand_api($expand) {
        $expand->_expand_parent = $this;
        array_unshift($this->_db_expand_list, $expand);
    }

    //--------------------------------------------------------------------------
    public function __call($name, $arguments) {
        $target = null;

        foreach ($this->_db_expand_list as $expand) {
            if (method_exists($expand, $name)) {
                $target = $expand;
                break;
            }
        }

        if (is_null($target)) {
            throw new \Exception(sprintf('Call to undefined method %s->%s()', get_class($this), $name));
        }

        return call_user_func_array(array($target, $name), $arguments);
    }

}
