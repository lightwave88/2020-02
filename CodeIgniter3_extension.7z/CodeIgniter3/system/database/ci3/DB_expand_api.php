<?php

namespace ci\system\database\ci3;

abstract class CI_DB_expand_api {

    /**
     * 外层的包裹(CI_DB)
     * 
     * @var type 
     */
    public $_expand_parent;

    //--------------------------------------------------------------------------
    public function __construct($wrap) {
        $this->_expand_parent = $wrap;
    }

    //--------------------------------------------------------------------------
    public function __call($key, $args) {
        if (method_exists($this->_expand_parent, $key)) {
            return call_user_func_array(array($this->_expand_parent, $key), $args);
        }
        throw new \Exception(sprintf('Call to undefined method %s->%s()', get_class($this), $key));
    }

    //--------------------------------------------------------------------------
    public function __get($key) {
        return $this->_expand_parent->$key;
    }

}
