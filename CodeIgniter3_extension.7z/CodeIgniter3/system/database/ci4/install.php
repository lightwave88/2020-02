<?php

namespace ci\database\ci3;

use ci\system\fun;

const MODULE_ROOT_DIR = __DIR__;

/**
 * 原本是 DB.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 * @param array $sys_info: 系統資訊
 * @param type $params: [(string)group_name|(array)options]
 * @return \ci\database\ci3\driver
 * @throws \Exception
 */
function &install(array $sys_info, $params = '') {

    $moduleName = @$sys_info['module_name'];

    $db_config = null;
    //-----------------------
    // load config
    // 取得 config 的路徑
    $config_dir_list = fun\coreConfig('database.config_dir');

    foreach ($config_dir_list as $dir) {
        $file = $dir . 'ci3/database.php';
        if (file_exists($file)) {
            include($file);
            $config_file_exists = true;
            goto anchor_1;
        }
    }
    throw new \Exception('The ci3 database configuration file database.php does not exist.');
    anchor_1:

    if (!isset($expand_api)) {
        throw new \Exception('The ci3 database configuration file no variable $expand_api');
    }
    //-----------------------
    if (is_array($params) && count($params) > 0) {
        $db_config = $params;
    } else if(is_string($params)){
        // 從 database.php 取得連線的參數
        // 連線參數
        if (!isset($db) OR count($db) === 0) {
            show_error('No database connection settings were found in the database config file.');
        }

        $active_group = empty($params) ? 'default' : $params;

        if (!isset($active_group)) {
            show_error('You have not specified a database connection group via $active_group in your config/database.php file.');
        }
        if (!isset($db[$active_group])) {
            show_error("You have specified an invalid database connection group ({$active_group}) in your config/database.php file.");
        }
        $db_config = $db[$active_group];
    }

    unset($db);
    unset($active_group);

    if (empty($db_config)) {
        throw new \Exception("database({$moduleName}) settings no exists");
    }
    //----------------------------
    if (!empty($db_config['dsn'])) {
        /**
         * Parse the URL from the DSN string
         * Database settings can be passed as discreet
         * parameters or as a data source name in the first
         * parameter. DSNs must have this prototype:
         * $dsn = 'driver://username:password@hostname/database';
         */
        if (($dsn = @parse_url($params['url'])) === FALSE) {
            show_error('Invalid DB Connection String');
        }

        $dsn_config = array(
            'dbdriver' => $dsn['scheme'],
            'hostname' => isset($dsn['host']) ? rawurldecode($dsn['host']) : '',
            'port' => isset($dsn['port']) ? rawurldecode($dsn['port']) : '',
            'username' => isset($dsn['user']) ? rawurldecode($dsn['user']) : '',
            'password' => isset($dsn['pass']) ? rawurldecode($dsn['pass']) : '',
            'database' => isset($dsn['path']) ? rawurldecode(substr($dsn['path'], 1)) : ''
        );

        foreach ($dsn_config as $k => $v) {
            $db_config[$k] = $v;
        }

        // Were additional config items set?
        if (isset($dsn['query'])) {
            parse_str($dsn['query'], $extra);

            foreach ($extra as $key => $val) {
                if (is_string($val) && in_array(strtoupper($val), array('TRUE', 'FALSE', 'NULL'))) {
                    $val = var_export($val, TRUE);
                }
                $db_config[$key] = $val;
            }
        }
    }
    //-----------------------
    if (!class_exists('\CI_DB', FALSE)) {
        /*
         * expand_api
         */

        $expand_str = '';

        // 尋找指定的擴增 api
        $expand_list = _find_expandAPI($expand_api);

        if (!is_null($expand_list)) {
            $expand_str = join(";\n", $expand_list) . ";\n";
        }
        //-----------------------

        $command = <<<command
        namespace ci\database\ci3 {
            class CI_DB_core {
        
                %s

                protected \$core_parent;
        
                public function __construct(\$parent) {
                    \$this->core_parent = \$parent;
                    \$this->core_parent->db_core = \$this;
                }
        
                public function __call(\$name, \$arguments) {
                    return call_user_func_array(array(\$this->core_parent, \$name), \$arguments);
                }
        
                public function __get(\$name) {
                    return \$this->core_parent->\$name;
                }
        
            }
        
        }
command;

        require_once(MODULE_ROOT_DIR . '/DB_driver.php');
        require_once(MODULE_ROOT_DIR . '/DB.php');

        $command = sprintf($command, $expand_str);
        
        console()->log('db command = %s', $command);

        try {
            eval($command);
        } catch (\Exception $e) {
            console()->log("command eval error(%s)", $e->getMessage());
        }

        console()->log('eval ok');

        $core_class = '\\ci\\database\\ci3\\CI_DB_core';
        if (!class_exists($core_class)) {
            throw new \Exception("generate class {$core_class} error");
        }
    }

    //-----------------------
    // No DB specified yet? Beat them senseless...
    if (empty($db_config['dbdriver'])) {
        show_error('You have not selected a database type to connect to.');
    }

    $driver = $db_config['dbdriver'];

    // Load the DB driver
    $driver_file = MODULE_ROOT_DIR . '/drivers/' . $driver . '/' . $driver . '_driver.php';

    if (!file_exists($driver_file)) {
        throw new \Exception("Invalid DB driver({$driver_file})");
    }
    
    require_once($driver_file);

    // Instantiate the DB adapter
    $driver_class = 'CI_DB_' . $driver . '_driver';
    $DB = new $driver_class($db_config);

    // Check for a subdriver
    if (!empty($DB->subdriver)) {
        $driver_file = MODULE_ROOT_DIR . '/drivers/' . $DB->dbdriver . '/subdrivers/' . $DB->dbdriver . '_' . $DB->subdriver . '_driver.php';

        if (file_exists($driver_file)) {
            require_once($driver_file);
            $driver_class = 'CI_DB_' . $DB->dbdriver . '_' . $DB->subdriver . '_driver';
            $DB = new $driver_class($params);
        }
    }
    new $core_class($DB);
    $DB->initialize();
    return $DB;
}

//------------------------------------------------------------------------------

/**
 * load expandAPI
 * 
 * @param array $moduleList
 * @return type
 * @throws \Exception
 */
function _find_expandAPI(array $moduleList) {

    // expandAPI 可能放置的路徑
    $dir_list = fun\coreConfig('database.ci3_expandAPI_dir');

    $namespace = fun\coreConfig('database.root_namespace');
    $namespace = $namespace . 'ci3\\';

    $trait_list = array();

    foreach ($moduleList as $module) {

        $fileName = ucfirst($module);
        $trait = $namespace . 'CI_' . $fileName;

        if (trait_exists($trait)) {
            // class 已經存在
            $trait_list[] = $trait;
            continue;
        } else {
            // class 尚未 load

            foreach ($dir_list as $dir) {

                $file = $dir . $fileName . '.php';

                if (file_exists($file)) {
                    require_once($file);
                    $find_file = true;

                    if (!trait_exists($trait)) {
                        throw new \Exception("trait({$module}) no exists");
                    }
                    $trait_list[] = $trait;
                    goto anchor_2;
                }
            }
            throw new \Exception("{$module} file no exists");
            anchor_2:
        }
    }
    //------------------
    foreach ($trait_list as &$trait) {
        $trait = 'use ' . $trait;
    }

    return (count($trait_list) > 0 ? $trait_list : null);
}
