<?php
namespace ci\libraries;

use ci\system\CI_Library;

class CI_Xyz extends CI_Library{
    public static $id = 0;
    public $number;
    
    public function __construct() {
        $this->number = self::$id++;
        \Console::log('Xyz init(%s)', $this->number);
    }

    public function initialize(){
        
    }
    
    public function getNumber(){
        \Console::log('id(%s)', $this->number);
    }
}
