<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

class CI_InterceptorsManager {

    /**
     * xml setting file
     * 
     * @var type 
     */
    const XML_FilePATH = 'config/interceptors.xml';

    /**
     * contollerName => settingObj
     * 
     * @var type 
     */
    static public $_ci_xmlSetting;

    /**
     * 執行時的 controller
     * 
     * @var type 
     */
    protected $_ci_controller;

    //--------------------------------------------------------------------------
    public function __construct() {
        if (!isset(self::$_ci_xmlSetting)) {
            $this->getXMLSetting();
        }
    }

    //--------------------------------------------------------------------------
    /**
     * 檢查 xml 更新時間
     * 是否需要更新 cache
     */
    protected function _checkXMLUpadate() {
        $path = '';
        $time = filemtime($path);
        
        if($time === FALSE){
            
        }
    }

    //--------------------------------------------------------------------------
    protected function _getXMLSetting() {
        
    }

    //--------------------------------------------------------------------------
    public function setController(\system\Controller $controller = NULL) {
        $this->_ci_controller = $controller;
    }

    //--------------------------------------------------------------------------
    public function interceptor_exists($interceptorName) {
        
    }

    //--------------------------------------------------------------------------
    public function interceptor_loadded($interceptorName) {
        
    }

    //--------------------------------------------------------------------------
    public function addInterceptor($interceptorName, $method = NULL, array $param = array()) {
        
    }

    //--------------------------------------------------------------------------
    public function setInterceptorParam($interceptorName, $method = NULL, array $param = array()) {
        
    }

}
