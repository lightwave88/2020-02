<?php

namespace ci\system;

/**
 * 新的 library 必須繼承
 */
abstract class CI_Library {

    //--------------------------------------------------------------------------
    /**
     * 任何的 __construct() 必須在此進行
     * __construct() 只有引入模組
     *
     * 此舉避免__construct() 階段
     * 模組相互引用，並執行，所造成的問題
     */
    abstract protected function initialize();
}
