<?php

namespace ci\system;

use ci\system\fun;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_ContainerABS')) {
    require_once(__DIR__ . '/ContainerABS.php');
}

/**
 * Description of CI_GlobalContext
 *
 * @author xman
 */
class CI_GlobalContext extends CI_ContainerABS {

    private static $instance;
    //------------------

    /**
     * List of loaded models
     *
     * @var	array
     */
    protected $_ci_single_models = array();

    /**
     * List of loaded helpers
     *
     * @var	array
     */
    protected $_ci_single_helpers = array();

    //--------------------------------------------------------------------------
    public function __construct() {
        parent::__construct();

        $class = SYS_ROOT_NAMESPACE . 'CI_Loader_basic';

        $file = BASEPATH . 'core1/Loader/Loader_basic.php';
        \include_class($file, $class, TRUE);
        $this->load = new $class($this);
    }

    //--------------------------------------------------------------------------
    // 返回一個全域對象
    public static function &get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    //--------------------------------------------------------------------------
}
