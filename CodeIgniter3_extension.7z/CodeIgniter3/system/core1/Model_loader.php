<?php

namespace ci\system;

use ci\system\fun;

/**
 * 職責是 load model
 */
class CI_Model_loader {

    const ROOT_CLASS = 'CI_Model';
    const ROOT_CLASS_FILENAME = 'Model.php';

    /**
     * 單例化的 model
     * @var type 
     */
    protected $_models = array();

    /**
     * model 的上下文
     * @var type 
     */
    protected $_model_context;

    //--------------------------------------------------------------------------
    public function __construct() {
        
    }

    //--------------------------------------------------------------------------
    public function &load_model($modelName, $single = true) {
        $single = !!$single;

        $list = fun\key_checkModuleName($modelName);

        $subdir = $list[0];
        $modelName = $list[1];

        $index = empty($list[0]) ? $list[1] : sprintf('%s\\%s', $list[0], $list[1]);
        $index = strtolower($index);

        if ($single && isset($this->_models[$index])) {
            return $this->_models[$index];
        }
        //------------------
        $this->_checkRootclass();
        //------------------
        $model_root_namespace = config('model_namespace');
        $class = $model_root_namespace . $subdir . $modelName;

        $i = 0;
        while (!class_exists($class)):
            if ($i > 0) {
                throw new \Exception("class(%s) no exists");
            }

            $model_dir = fun\coreConfig('model.class_dir');
            $file = $model_dir . $subdir . $modelName . '.php';

            if (!file_exists($file)) {
                throw new \Exception("model({$class}) file no exists ({$file})");
            }
            require_once($file);
            $i++;
        endwhile;

        $model = new $class();

        if ($single) {
            $this->_models[$index] = &$model;
        }
        return $model;
    }

    //--------------------------------------------------------------------------
    protected function _checkRootclass() {

        $subclass_prefix = \config('subclass_prefix');
        $namespace = fun\coreConfig('core.root_namespace');

        $class = $namespace . self::ROOT_CLASS;

        $extend_class = preg_replace('/^[^_]*?_/', '', self::ROOT_CLASS);
        $extend_class = $namespace . $subclass_prefix . $extend_class;

        if (class_exists($extend_class) || class_exists($class)) {
            return;
        }
        //-----------------------
        $className = $class;

        $dirlist = fun\coreConfig('core.module_dir');

        if (!is_array($dirlist)) {
            $dirlist = array($dirlist);
        }

        $index = null;
        foreach ($dirlist as $k => $dir) {
            $file = $dir . self::ROOT_CLASS_FILENAME;

            if (file_exists($file)) {
                require_once($file);
                $index = $k;
                break;
            }
        }

        if (is_null($index)) {
            throw new \Exception("class({self::ROOT_CLASS}) file no exists");
        }

        if (!class_exists($className)) {
            throw new \Exception("class({$className}) no exists");
        }
        //------------------
        if ($index > 0):
            $file = $dirlist[1] . $subclass_prefix . self::ROOT_CLASS_FILENAME;

            if (file_exists($file)) {
                require_once($file);
                $className = $extend_class;

                if (!class_exists($className)) {
                    throw new \Exception("class({$className}) no exists");
                }
            }
        endif;
    }

    //--------------------------------------------------------------------------
}
