<?php

class Console {

    protected static $_ci_core;
    protected static $instance;

    //--------------------------------------------------------------------------
    protected function __construct($core) {
        self::$instance = &$this;
        self::$_ci_core = $core;
        // Console()->var_dump(self::$_ci_core);
    }

    //--------------------------------------------------------------------------
    public static function __callStatic($name, $arguments) {
        // Console()->var_dump(self::$_ci_core);
        return call_user_func_array(array(self::$_ci_core, $name), $arguments);
    }

    //--------------------------------------------------------------------------
    public static function &get_instance($core) {
        if (!isset(self::$instance)) {
            self::$instance = new self($core);
        }
        return self::$instance;
    }

}
