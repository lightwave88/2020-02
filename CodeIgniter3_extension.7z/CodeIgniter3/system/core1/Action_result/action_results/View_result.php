<?php

namespace ci\system\result;

if (!class_exists('CI_ActionResult')) {
    $file = __DIR__ . '/../Action_result.php';
    require_once($file);
}

/**
 * 供繼承用
 * view engine 必須繼承
 */
interface Veiw_result extends CI_ActionResult_output {
    
}
