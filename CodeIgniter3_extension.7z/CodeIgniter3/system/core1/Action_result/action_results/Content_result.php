<?php

namespace ci\system\result;

class CI_Content_result implements CI_ActionResult_output {

    public $_ci_content_type;
    public $_ci_download_name;
    protected $_ci_content;

    public function __construct($content, $contentType, $downloadName = '') {
        $this->_ci_content = '' . $content;
        $this->_ci_content_type = $contentType;

        if (!empty($downloadName)) {
            $this->_ci_download_name = $downloadName;
        }
    }

    //--------------------------------------------------------------------------
    public function setContentType($type) {
        $this->_ci_content_type = $type;
    }

    //--------------------------------------------------------------------------
    public function setDownloadName($name) {
        $this->_ci_download_name = $name;
    }

    //--------------------------------------------------------------------------
    public function ExecuteResult() {
        
    }

    //--------------------------------------------------------------------------
    public function getOutput() {
        return $this->_ci_content;
    }

}
