<?php

namespace ci\system\result;

class CI_Cache_result{

}
