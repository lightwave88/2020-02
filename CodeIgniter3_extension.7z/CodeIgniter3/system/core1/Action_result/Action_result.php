<?php

namespace ci\system\result;

interface CI_ActionResult {

    public function ExecuteResult();
}

//------------------------------------------------------------------------------

interface CI_ActionResult_output extends CI_ActionResult {

    /**
     * 是否有輸出
     */
    public function getOutput();
}

//------------------------------------------------------------------------------

interface CI_ActionResult_redirect extends CI_ActionResult {

    /**
     * 是否有重新導向
     */
    public function getRedirect();
}
