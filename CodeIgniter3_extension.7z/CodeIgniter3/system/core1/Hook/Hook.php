<?php

namespace ci\system\hook;

use ci\system\CI_Item1_container;
use ci\system\fun;

if (!class_exists('CI_Item1_container')) {
    $file = BASEPATH . 'core1/Container/ContainerABS.php';
    require_once($file);
}

/**
 * hook container
 */
abstract class CI_Hook extends CI_Item1_container {

    public function __construct() {

        parent::__construct();

        fun\container_load_cores($this);

        $className = SYS_ROOT_NAMESPACE . 'CI_Loader_basic';
        $path = BASEPATH . '/core1/Loader/Loader_basic.php';
        $this->load = &fun\load_class($className, $path, array($this), FALSE);
    }

    // -------------------------------------------------------------------------
}
