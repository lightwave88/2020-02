<?php

namespace ci\system;

use ci\system\fun;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_Loader_basic')) {
    $file = __DIR__ . '/Loader_basic.php';
    require_once($file);
}

/**
 * 針對 context 是 $CI 的 container
 * 如 HookContainer
 */
class CI_Controller_loader extends CI_Loader_basic {

    //--------------------------------------------------------------------------
    public function view($engine = null, array $init = array()) {
        $view = fun\get_viewEngine($this->_ci_container, $engine, $init);
        return $view;
    }

    //--------------------------------------------------------------------------
    public function filters() {
        if ($this->_ci_container->_ci_inited) {
            // 只能在 __construct 時使用
            return;
        }
    }

    //--------------------------------------------------------------------------
    public function result() {

        $args = func_get_args();
        $ressultName = array_shift($args);

        $class = '';

        if ($this->_ci_container->_ci_level > 0) {
            // 屬於 child
            // 只能返回 \system\result\CI_ActionResult_output
            // 不能返回 layout
        } else {
            $class = fun\get_actionResult($resultName);
        }

        $result_obj = \instance_class($class, $args);

        return $result_obj;
    }

}
