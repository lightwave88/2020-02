<?php

namespace ci\system;

/**
 * 
 */
trait CI_Loader_trait_file {

    public function file() {
        
    }

}
