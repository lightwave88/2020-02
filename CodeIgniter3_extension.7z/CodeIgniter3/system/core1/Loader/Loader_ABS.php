<?php

namespace ci\system;

defined('BASEPATH') OR exit('No direct script access allowed');

abstract class CI_Loader_ABS {

    /**
     * 所屬的 container
     */
    protected $_ci_container;

    //--------------------------------------------------------------------------
    public function __construct(\ci\system\CI_ContainerABS $container) {
        $this->_ci_container = &$container;


        $lib_abs_class = SYS_ROOT_NAMESPACE . 'CI_Library';
        if (!class_exists($lib_abs_class)) {
            /**
             * 新 library 要用的
             */
            $file = BASEPATH . 'core1/Library.php';
            \include_class($file, $lib_abs_class, TRUE);
        }
    }

    //--------------------------------------------------------------------------
    public function initialize() {
        
    }

    //--------------------------------------------------------------------------
    abstract public function is_loaded($class);

    abstract public function library($moduleName, $params = NULL, $object_name = NULL, $single = TRUE);

    /**
     * library 的簡寫
     * 把 lib 注入到全局對象
     *
     * @param type $library
     * @param type $params
     * @param type $object_name
     */
    abstract public function lib($moduleName, $params = NULL, $name = NULL, $single = TRUE);

    abstract public function app($object_name, $class, $params = NULL, $name = NULL, $single = TRUE);

    abstract public function model($model, $name = NULL, $single = TRUE);

    abstract public function helper($helpers = array());

    abstract public function helpers($helpers = array());

    abstract public function driver($library, $params = NULL, $object_name = NULL);

    abstract public function language($files, $lang = '');

    abstract public function config($file, $use_sections = FALSE, $fail_gracefully = FALSE);

    // old api
    abstract public function get_package_paths($include_base = FALSE);

    abstract public function database($params = null, $return = FALSE);
}
