<?php


class ManTool{
    public function __construct() {
        var_dump('hi');
    }   
}

$x = new mantool();
