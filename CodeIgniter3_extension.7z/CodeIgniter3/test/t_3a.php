<?php

$str = '\\a\\b\\c';

$index = strrpos($str, 'g');

var_dump($index);

//printf('<p>%s => %s</p>', substr($str, 0, ++$index), substr($str, $index));


