
import $parent from './m_1.js';

debugger;

const b = {
    name: 'b',
    getName() {
        debugger;
        return `${this.name} : ${$parent.name}`;
    }
};

debugger;

export { b as default };

debugger;