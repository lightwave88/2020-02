import $child from './m_2.js';

debugger;

const a = {
    name: 'a',
    getName() {
        debugger;
        return `${this.name} => ${$child.getName()}`;
    }
};

debugger;

export { a as default };

debugger;