<?php

class Factory {

    protected $section_contents = array();
    protected $temp_nested_list = array();
    protected $all_content = '';

    //--------------------------------------------------------------------------
    public function __construct() {
        $file = __DIR__ . '/template_1.php';
        if (!file_exists($file)) {
            throw new Exception("file({$file}) no exists");
        }
        ob_start();
        require($file);
        $this->all_content = ob_get_clean();
        echo $this->all_content;
    }

    //--------------------------------------------------------------------------
    public function extend() {
        
    }

    //--------------------------------------------------------------------------
    public function section($secttion_name) {
        ob_start();

        if (isset($this->section_contents[$secttion_name])) {
            throw new Exception("section({$secttion_name}) has declear");
        }

        array_push($this->temp_nested_list, $secttion_name);
    }

    //--------------------------------------------------------------------------
    public function endSection($s_name) {
        $content = ob_get_clean();
        $section_name = array_pop($this->temp_nested_list);

        if (strcmp($section_name, $s_name) != 0) {
            throw new Exception("section start(${$section}) not match end({$s_nsme})");
        }

        $this->section_contents[$section_name] = $content;
        echo sprintf('(%s)%s', $section_name, $content);
    }

}

$f = new Factory();
print('--------------------');
var_dump($f);
